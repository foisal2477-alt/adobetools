export const INITIAL_GLOBAL_EVENTS = [
  {
    name: "New Year & Fresh Starts",
    date: "2026-01-01",
    month: 1,
    countryCode: "GLOBAL",
    category: "holiday",
    description: "Celebrations, goal-setting, fitness resolutions, business planning, and new calendar year themes.",
    leadTimeWeeks: 8,
    suggestedKeywords: "new year, celebration, resolution, fitness, fresh start, business planning, toast, confetti, party, goals 2026",
    contentIdeas: [
      "People setting digital planners and writing goals on minimalist journals with copy space",
      "Diverse groups celebrating with champagne flutes and sparklers (no visible branded bottles)",
      "Morning jogger stretching at sunrise symbolizing new wellness routines",
      "Empty calendar desk flatlay with golden stationery and subtle bokeh"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Lunar New Year / Spring Festival",
    date: "2026-02-17",
    month: 2,
    countryCode: "GLOBAL",
    category: "cultural",
    description: "Major celebration across Asia and worldwide diaspora featuring red lanterns, family reunions, feasts, and zodiac motifs.",
    leadTimeWeeks: 9,
    suggestedKeywords: "lunar new year, chinese new year, spring festival, red envelope, dumplings, family dinner, lanterns, traditions, prosperity",
    contentIdeas: [
      "Multi-generational Asian family gathering around steaming hotpot or dumplings",
      "Hands gifting traditional red envelopes (hongbao) with decorative gold foil",
      "Macro shot of traditional tea ceremony set with auspicious citrus fruits",
      "Modern minimalist flatlay of paper cuttings, calligraphy brushes, and red envelopes"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Valentine's Day & Relationship Trends",
    date: "2026-02-14",
    month: 2,
    countryCode: "GLOBAL",
    category: "commercial",
    description: "High commercial demand for romance, modern dating, self-love, friendship (Galentine's), and jewelry/gift concepts.",
    leadTimeWeeks: 7,
    suggestedKeywords: "valentines day, romance, couple, love, dating, gift, self care, flowers, heart, jewelry, dinner, modern relationship",
    contentIdeas: [
      "Authentic LGBTQ+ and diverse couples laughing naturally during intimate home dinner",
      "Self-care pampering setup: bath salts, candle, dried roses, and book",
      "Hands exchanging wrapped artisan gift box with velvet ribbon on marble surface",
      "Creative heart-shaped shadows or abstract light reflections with generous copy space"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "International Women's Day (IWD)",
    date: "2026-03-08",
    month: 3,
    countryCode: "GLOBAL",
    category: "awareness",
    description: "Huge editorial and commercial demand for female leadership, STEM innovators, female entrepreneurship, and community unity.",
    leadTimeWeeks: 8,
    suggestedKeywords: "international womens day, female leadership, women in business, diversity, empowerment, stem, teamwork, equality, mentor",
    contentIdeas: [
      "Female aerospace or software engineer mentoring junior colleague in modern tech lab",
      "Diverse group of confident professional women of varying ages in executive boardroom",
      "Mother and daughter gardening or coding together representing generational progress",
      "Artisan female small-business founder crafting sustainable goods in sunlit workshop"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Ramadan & Eid al-Fitr",
    date: "2026-03-11",
    month: 3,
    countryCode: "GLOBAL",
    category: "cultural",
    description: "Holy month of fasting, reflection, charity, community iftar meals, culminating in joyous Eid festivities.",
    leadTimeWeeks: 8,
    suggestedKeywords: "ramadan, eid al fitr, iftar meal, dates, crescent moon, prayer, fasting, islamic culture, generosity, family gathering",
    contentIdeas: [
      "Modern Muslim family breaking fast at sunset with dates, water, and warm home-cooked spread",
      "Intricate lantern (Fanous) casting warm decorative geometric shadows on rustic table",
      "Hands offering dates on a brass platter with clean background and elegant negative space",
      "Community food donation drive illustrating the spirit of Zakat and giving"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Earth Day & Sustainability Focus",
    date: "2026-04-22",
    month: 4,
    countryCode: "GLOBAL",
    category: "awareness",
    description: "One of the most downloaded corporate themes: green energy, circular economy, recycling, reforestation, and eco-living.",
    leadTimeWeeks: 8,
    suggestedKeywords: "earth day, sustainability, solar energy, recycling, renewable, climate action, ecology, zero waste, electric vehicle, green tech",
    contentIdeas: [
      "Solar panel technician inspecting rooftop array with digital tablet under blue skies",
      "Hands planting young seedling in rich soil with morning dew and sunlight flare",
      "Zero-waste pantry setup with glass jars, organic grains, and linen shopping totes",
      "Architect reviewing sustainable green building blueprint with living plant wall background"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Mother's Day & Family Dynamics",
    date: "2026-05-10",
    month: 5,
    countryCode: "US",
    category: "commercial",
    description: "Top microstock sales period for maternal bonds, modern motherhood, breakfast in bed, and multi-generational moments.",
    leadTimeWeeks: 7,
    suggestedKeywords: "mothers day, mother, mom, daughter, parenting, family hug, breakfast in bed, flowers, gratitude, toddler, generations",
    contentIdeas: [
      "Toddler surprising mother with messy pancakes and wildflower bouquet in cozy kitchen",
      "Three generations of women (grandmother, mother, granddaughter) laughing outdoor in park",
      "Single working mother balancing laptop work and playful child with authentic emotion",
      "Handwritten card reading 'Thank You Mom' next to delicate peonies and coffee cup"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Father's Day & Active Fatherhood",
    date: "2026-06-21",
    month: 6,
    countryCode: "GLOBAL",
    category: "commercial",
    description: "High commercial demand moving away from stereotypes toward tender, nurturing, and hands-on modern fatherhood.",
    leadTimeWeeks: 7,
    suggestedKeywords: "fathers day, father, dad, parenting, father and son, teaching, bicycle, bonding, outdoor adventure, nurturing dad",
    contentIdeas: [
      "Father teaching young daughter how to ride bicycle on quiet suburban street",
      "Dad gently tying hair or reading bedtime fairy tale to sleepy toddler",
      "Father and son woodworking or assembling DIY project in garage workshop",
      "Outdoor camping trip with father and kids stargazing beside cozy tent"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Pride Month & LGBTQ+ Visibility",
    date: "2026-06-01",
    month: 6,
    countryCode: "GLOBAL",
    category: "awareness",
    description: "Sustained year-round demand for authentic LGBTQ+ representations in corporate, healthcare, family, and social settings.",
    leadTimeWeeks: 8,
    suggestedKeywords: "pride month, lgbtq, pride, diversity, equality, rainbow, modern couple, inclusion, love is love, community",
    contentIdeas: [
      "Same-sex couple grocery shopping or preparing meal together in modern apartment",
      "Corporate workplace showing rainbow lanyard, welcoming culture, and diverse teamwork",
      "Friends holding pride flags celebrating joyfully at outdoor summer festival",
      "Warm portrait of trans individual looking confident and authentic in casual daylight"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Summer Vacations & Outdoor Travel",
    date: "2026-07-01",
    month: 7,
    countryCode: "GLOBAL",
    category: "seasonal",
    description: "Peak tourism, staycations, beach getaways, road trips, wellness retreats, and remote summer work concepts.",
    leadTimeWeeks: 10,
    suggestedKeywords: "summer, travel, vacation, beach, road trip, tourism, vanlife, hiking, sunshine, swimming, leisure, holiday",
    contentIdeas: [
      "Friends sitting on tailgate of camper van watching coastal sunset with guitars",
      "Overhead drone shot of turquoise ocean waves with solitary swimmer creating ripple texture",
      "Solo female backpacker checking navigation app on mountain ridge viewpoint",
      "Refreshing iced matcha latte and sunglasses on poolside teak lounge chair"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Back to School & EdTech",
    date: "2026-08-15",
    month: 8,
    countryCode: "GLOBAL",
    category: "commercial",
    description: "Crucial commercial season for school supplies, university students, online learning, STEM classrooms, and study habits.",
    leadTimeWeeks: 8,
    suggestedKeywords: "back to school, education, classroom, students, edtech, notebook, backpack, university, homework, learning, stem",
    contentIdeas: [
      "Diverse high school students collaborating on robotics project with 3D printer",
      "Flatlay of organized stationery: notebook, pastel highlighters, laptop, and apples",
      "Parent walking little kid with oversized backpack on first day of primary school",
      "College student studying in aesthetic sunlit university library with coffee and tablet"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Autumn Harvest & Cozy Lifestyle",
    date: "2026-09-22",
    month: 9,
    countryCode: "GLOBAL",
    category: "seasonal",
    description: "Warm color palettes, pumpkin spice, cozy knits, autumn foliage, farmers markets, and seasonal cooking.",
    leadTimeWeeks: 7,
    suggestedKeywords: "autumn, fall foliage, harvest, cozy, pumpkin, sweater weather, leaves, cider, farmers market, warm beverage",
    contentIdeas: [
      "Person wrapped in chunky knit blanket holding steaming ceramic mug near window with falling leaves",
      "Farmers market stand filled with heirloom pumpkins, fresh apples, and rustic burlap sacks",
      "Golden retriever running through golden-orange maple leaves in sunlit park",
      "Autumn baking flatlay: cinnamon sticks, pie dough, rolling pin, and sliced pecans"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Halloween & Spooky Season",
    date: "2026-10-31",
    month: 10,
    countryCode: "US",
    category: "cultural",
    description: "Heavy advertising and retail demand for costumes, trick-or-treating, home decor, parties, and spooky confectionery.",
    leadTimeWeeks: 9,
    suggestedKeywords: "halloween, pumpkin, costume, jack o lantern, trick or treat, candy, autumn, spooky, party, autumn decor",
    contentIdeas: [
      "Kids in handmade whimsical costumes holding pumpkin buckets under porch light",
      "Carved glowing Jack-o'-lantern on dark rustic wooden steps with dried corn stalks",
      "Flatlay of Halloween artisan cookies, cupcakes with ghost icing, and dark treats",
      "Creative studio lighting concept with eerie fog and moody silhouette lighting"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Diwali - Festival of Lights",
    date: "2026-11-08",
    month: 11,
    countryCode: "IN",
    category: "cultural",
    description: "Vibrant global festival symbolizing light over darkness; high demand for traditional attire, diyas, sweets, and family joy.",
    leadTimeWeeks: 8,
    suggestedKeywords: "diwali, deepavali, festival of lights, diya, rangoli, celebration, indian culture, sweets, traditional clothing, sparklers",
    contentIdeas: [
      "Close-up of hands arranging oil clay lamps (diyas) around a colorful flower rangoli pattern",
      "Smiling family in traditional embroidered silk attire lighting gentle sparklers",
      "Platter of traditional Indian mithai sweets decorated with silver vark and pistachios",
      "Interior home decoration with marigold garlands, warm fairy lights, and copper brass urns"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Black Friday & Cyber Week E-Commerce",
    date: "2026-11-27",
    month: 11,
    countryCode: "GLOBAL",
    category: "commercial",
    description: "The biggest retail shopping season of the year. Essential for marketing banners, payment concepts, delivery, and bargains.",
    leadTimeWeeks: 10,
    suggestedKeywords: "black friday, cyber monday, shopping, e commerce, discount, sale, delivery, credit card, retail, online shopping, parcel",
    contentIdeas: [
      "Courier delivery driver carrying stack of eco-friendly cardboard parcels to home doorstep",
      "Person using smartphone in bed checking shopping discount banners with credit card in hand",
      "High-end luxury shopping bags with golden sale tags on sleek dark background with copy space",
      "Warehouse automated sorting conveyor with parcels moving swiftly under industrial lights"
    ],
    isPopularStockTheme: true,
  },
  {
    name: "Christmas, Hanukkah & Winter Holidays",
    date: "2026-12-25",
    month: 12,
    countryCode: "GLOBAL",
    category: "holiday",
    description: "Adobe Stock's highest selling holiday category. Needs submission by October for maximum algorithm indexing.",
    leadTimeWeeks: 11,
    suggestedKeywords: "christmas, winter holidays, hanukkah, gift wrapping, family dinner, christmas tree, festive, gingerbread, fireplace, snow",
    contentIdeas: [
      "Cozy hands tying twine bow on recycled craft paper gift box with pine branch accent",
      "Multi-generational family sharing laughter around a beautifully decorated Christmas dinner table",
      "Minimalist Nordic holiday living room with subtle warm fairy lights and modern pine wreath",
      "Baking session with children cutting gingerbread men cookies sprinkled with flour on wooden board"
    ],
    isPopularStockTheme: true,
  }
];

export const INITIAL_SHOT_PLANS = [
  {
    title: "Eco-Friendly Commuting & Urban Mobility",
    themeCategory: "Sustainability",
    targetAgency: "Adobe Stock",
    shootDate: "2026-05-18",
    submissionDeadline: "2026-06-01",
    status: "in_production",
    estimatedEarnings: 850,
    targetImageCount: 24,
    location: "Downtown Green Plaza & Metro Station",
    gearNotes: "Sony A7 IV + 24-70mm f/2.8 GM, CPL filter to cut glass reflections, lightweight reflector",
    keywords: "urban mobility, electric scooter, commuting, sustainability, public transit, city life, young professional, carbon neutral",
    shotList: [
      "Professional woman with helmet folding e-scooter next to modern transit hub",
      "Close-up of hands tapping digital transit payment card at subway turnstile",
      "Cyclist in business casual clothing waiting at dedicated bicycle lane traffic signal",
      "Wide scenic shot of solar-powered tram passing through modern glass architecture"
    ],
    notes: "Ensure zero trademarks on scooter frame and clothing. Obtain signed adult model releases."
  },
  {
    title: "Generative AI Workplace & Hybrid Team Collaboration",
    themeCategory: "Business & Tech",
    targetAgency: "Adobe Stock",
    shootDate: "2026-04-10",
    submissionDeadline: "2026-04-20",
    status: "ready_for_review",
    estimatedEarnings: 1200,
    targetImageCount: 30,
    location: "Bright Co-working Loft & Conference Room",
    gearNotes: "Canon R5 + 50mm f/1.2, 85mm f/1.4, Godox softboxes for clean diffused high-key lighting",
    keywords: "artificial intelligence, future of work, hybrid team, video call, technology, data analytics, modern office, collaboration",
    shotList: [
      "Team pointing at holographic/digital data dashboard on transparent glass wall",
      "Engineer prompting AI agent with custom prompt on ultra-wide curved monitor",
      "Diverse colleagues in casual wear celebrating successful sprint launch",
      "Minimalist flatlay of smartphone, wireless earbuds, notebook, and cold brew coffee"
    ],
    notes: "Keep screens displaying generic mock interfaces to pass Adobe Stock intellectual property checks."
  },
  {
    title: "Autumn Wellness & Mental Health Outdoor Retreat",
    themeCategory: "Lifestyle & Health",
    targetAgency: "Adobe Stock",
    shootDate: "2026-08-25",
    submissionDeadline: "2026-09-05",
    status: "planned",
    estimatedEarnings: 650,
    targetImageCount: 18,
    location: "Pine Forest Lake & Wooden Cabin Deck",
    gearNotes: "Nikon Z8 + 70-200mm f/2.8 for gentle background compression and creamy bokeh",
    keywords: "mental health, wellness, meditation, mindfulness, nature therapy, solitude, autumn, breathwork, relaxation",
    shotList: [
      "Individual sitting in peaceful meditation pose on wooden dock above calm misty lake",
      "Hands warming around handcrafted pottery mug with steam visible against foliage",
      "Walking barefoot through pine needles and moss in soft morning light",
      "Journaling thoughts in blank notebook with pressed maple leaf bookmark"
    ],
    notes: "Submit 8 weeks before World Mental Health Day (October 10) for peak search traffic."
  }
];
