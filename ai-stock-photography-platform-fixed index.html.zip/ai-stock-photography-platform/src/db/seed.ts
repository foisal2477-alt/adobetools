import { db } from "@/db";
import { globalEvents, shotPlans, contributorSettings } from "./schema";
import { INITIAL_GLOBAL_EVENTS, INITIAL_SHOT_PLANS } from "./seed-data";
import { sql } from "drizzle-orm";

export async function ensureSeedData() {
  try {
    const existingEvents = await db.select({ count: sql<number>`count(*)` }).from(globalEvents);
    const count = Number(existingEvents[0]?.count || 0);

    if (count === 0) {
      console.log("Seeding initial global events...");
      await db.insert(globalEvents).values(INITIAL_GLOBAL_EVENTS);
    }

    const existingShoots = await db.select({ count: sql<number>`count(*)` }).from(shotPlans);
    const shootsCount = Number(existingShoots[0]?.count || 0);

    if (shootsCount === 0) {
      console.log("Seeding initial shot plans...");
      await db.insert(shotPlans).values(INITIAL_SHOT_PLANS);
    }

    const existingSettings = await db.select({ count: sql<number>`count(*)` }).from(contributorSettings);
    const settingsCount = Number(existingSettings[0]?.count || 0);

    if (settingsCount === 0) {
      await db.insert(contributorSettings).values({
        contributorName: "Adobe Stock Pro Contributor",
        replicateApiKey: "",
        stabilityApiKey: "",
        defaultScaleFactor: 4,
        defaultModel: "Real-ESRGAN v3 Photo Super-Res",
        autoDenoise: true,
        autoSharpen: true,
        targetColorSpace: "sRGB",
        minMegapixels: 12,
        exportFormat: "JPEG (High 95%)",
      });
    }
  } catch (error) {
    console.error("Error in ensureSeedData:", error);
  }
}
