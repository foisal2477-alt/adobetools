import { pgTable, serial, text, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";

export const globalEvents = pgTable("global_events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  month: integer("month").notNull(), // 1 - 12
  countryCode: text("country_code").notNull().default("GLOBAL"), // e.g. "GLOBAL", "US", "UK", "IN", "JP", "DE"
  category: text("category").notNull(), // "cultural", "commercial", "holiday", "awareness", "seasonal", "sports"
  description: text("description").notNull(),
  leadTimeWeeks: integer("lead_time_weeks").notNull().default(6), // stock lead time recommendation
  suggestedKeywords: text("suggested_keywords").notNull(), // comma-separated
  contentIdeas: jsonb("content_ideas").$type<string[]>(), // list of visual shot suggestions
  isPopularStockTheme: boolean("is_popular_stock_theme").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const shotPlans = pgTable("shot_plans", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  themeCategory: text("theme_category").notNull().default("Lifestyle"),
  targetAgency: text("target_agency").notNull().default("Adobe Stock"), // "Adobe Stock", "Shutterstock", "Getty", "Freepik", "All"
  shootDate: text("shoot_date"), // YYYY-MM-DD
  submissionDeadline: text("submission_deadline"), // YYYY-MM-DD
  status: text("status").notNull().default("planned"), // "planned", "in_production", "ready_for_review", "submitted", "accepted", "rejected"
  estimatedEarnings: integer("estimated_earnings").default(0), // in USD
  targetImageCount: integer("target_image_count").default(15),
  location: text("location"),
  gearNotes: text("gear_notes"),
  keywords: text("keywords"),
  shotList: jsonb("shot_list").$type<string[]>(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const upscaleHistory = pgTable("upscale_history", {
  id: serial("id").primaryKey(),
  fileName: text("file_name").notNull(),
  originalWidth: integer("original_width").notNull(),
  originalHeight: integer("original_height").notNull(),
  upscaledWidth: integer("upscaled_width").notNull(),
  upscaledHeight: integer("upscaled_height").notNull(),
  scaleFactor: integer("scale_factor").notNull(), // 2, 4, 8
  aiModel: text("ai_model").notNull().default("Real-ESRGAN v3 Photo"),
  qualityScore: integer("quality_score").default(88), // 0-100 Adobe Stock Quality Score
  fileSizeKb: integer("file_size_kb"),
  status: text("status").notNull().default("completed"),
  detectedIssues: jsonb("detected_issues").$type<{
    category: string;
    level: "pass" | "warning" | "critical";
    message: string;
    score: number;
  }[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contributorSettings = pgTable("contributor_settings", {
  id: serial("id").primaryKey(),
  contributorName: text("contributor_name").default("Stock Contributor"),
  replicateApiKey: text("replicate_api_key").default(""),
  stabilityApiKey: text("stability_api_key").default(""),
  defaultScaleFactor: integer("default_scale_factor").default(4),
  defaultModel: text("default_model").default("Real-ESRGAN v3 Photo"),
  autoDenoise: boolean("auto_denoise").default(true),
  autoSharpen: boolean("auto_sharpen").default(true),
  targetColorSpace: text("target_color_space").default("sRGB"),
  minMegapixels: integer("min_megapixels").default(12),
  exportFormat: text("export_format").default("JPEG (High 95%)"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
