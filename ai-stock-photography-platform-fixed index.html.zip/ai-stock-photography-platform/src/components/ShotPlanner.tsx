"use client";

import React, { useState, useEffect } from "react";
import {
  Camera,
  Plus,
  CheckCircle2,
  Clock,
  DollarSign,
  Layers,
  MapPin,
  Sparkles,
  Trash2,
  Edit2,
  FileText,
  Tag,
  Check,
  ChevronDown,
  X,
  Target,
  TrendingUp,
} from "lucide-react";
import { useToast } from "./Toast";

export interface ShootPlan {
  id: number;
  title: string;
  themeCategory: string;
  targetAgency: string;
  shootDate: string | null;
  submissionDeadline: string | null;
  status: "planned" | "in_production" | "ready_for_review" | "submitted" | "accepted" | "rejected";
  estimatedEarnings: number;
  targetImageCount: number;
  location: string | null;
  gearNotes: string | null;
  keywords: string | null;
  shotList: string[] | null;
  notes: string | null;
  createdAt: string;
}

const STATUS_CONFIG = {
  planned: { label: "Planned", color: "bg-slate-800 text-slate-300 border-slate-700" },
  in_production: { label: "In Production", color: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
  ready_for_review: { label: "Ready for Review", color: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
  submitted: { label: "Submitted", color: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
  accepted: { label: "Accepted / Earning", color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" },
  rejected: { label: "Rejected", color: "bg-rose-500/20 text-rose-300 border-rose-500/30" },
};

export function ShotPlanner() {
  const { toast } = useToast();
  const [shoots, setShoots] = useState<ShootPlan[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  // Create Modal
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState("");
  const [newCategory, setNewCategory] = useState("Lifestyle");
  const [newAgency, setNewAgency] = useState("Adobe Stock");
  const [newShootDate, setNewShootDate] = useState("2026-05-20");
  const [newDeadline, setNewDeadline] = useState("2026-06-05");
  const [newEarnings, setNewEarnings] = useState(750);
  const [newImageCount, setNewImageCount] = useState(20);
  const [newLocation, setNewLocation] = useState("");
  const [newGear, setNewGear] = useState("");
  const [newKeywords, setNewKeywords] = useState("");
  const [newShotList, setNewShotList] = useState("");
  const [newNotes, setNewNotes] = useState("");

  const fetchShoots = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/shoots");
      if (res.ok) {
        const data = await res.json();
        setShoots(data.shoots || []);
      }
    } catch {
      toast({ type: "error", title: "Failed to load shot plans" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShoots();
  }, []);

  const handleCreateShoot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const shotsArray = newShotList
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      const res = await fetch("/api/shoots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newTitle,
          themeCategory: newCategory,
          targetAgency: newAgency,
          shootDate: newShootDate || null,
          submissionDeadline: newDeadline || null,
          status: "planned",
          estimatedEarnings: Number(newEarnings || 0),
          targetImageCount: Number(newImageCount || 15),
          location: newLocation,
          gearNotes: newGear,
          keywords: newKeywords,
          shotList: shotsArray,
          notes: newNotes,
        }),
      });

      if (res.ok) {
        toast({ type: "success", title: "Shoot Planned", description: `"${newTitle}" added to tracker.` });
        setIsModalOpen(false);
        // reset form
        setNewTitle("");
        setNewShotList("");
        setNewNotes("");
        fetchShoots();
      }
    } catch {
      toast({ type: "error", title: "Error creating shoot" });
    }
  };

  const handleUpdateStatus = async (id: number, status: ShootPlan["status"]) => {
    try {
      const res = await fetch("/api/shoots", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      if (res.ok) {
        setShoots((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
        toast({
          type: "success",
          title: "Status Updated",
          description: `Shoot status changed to ${status.replace("_", " ")}.`,
        });
      }
    } catch {
      toast({ type: "error", title: "Failed to update status" });
    }
  };

  const handleDeleteShoot = async (id: number) => {
    try {
      const res = await fetch(`/api/shoots?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setShoots((prev) => prev.filter((s) => s.id !== id));
        toast({ type: "info", title: "Shoot removed" });
      }
    } catch {
      toast({ type: "error", title: "Failed to delete" });
    }
  };

  // Stats
  const totalPlanned = shoots.length;
  const inProduction = shoots.filter((s) => s.status === "in_production").length;
  const readyOrSubmitted = shoots.filter((s) => s.status === "ready_for_review" || s.status === "submitted").length;
  const totalTargetEarnings = shoots.reduce((sum, s) => sum + (s.estimatedEarnings || 0), 0);
  const totalTargetAssets = shoots.reduce((sum, s) => sum + (s.targetImageCount || 0), 0);

  const filteredShoots = shoots.filter((s) => {
    if (filterStatus === "all") return true;
    return s.status === filterStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1">
                <Target className="w-3 h-3" /> Contributor Operations
              </span>
              <span className="text-xs text-slate-400">Microstock Pipeline & Shot Lists</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-2">Shot Planner & Portfolio Pipeline</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Organize commercial photo sessions, track shot lists, manage agency deadlines, and monitor projected stock revenue.
            </p>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 transition-all self-start lg:self-center"
          >
            <Plus className="w-4 h-4" /> Plan New Shoot
          </button>
        </div>

        {/* Stats Strip */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-xs text-slate-400 block">Total Active Shoots</span>
            <span className="text-2xl font-bold text-white mt-1 block">{totalPlanned}</span>
            <span className="text-[10px] text-cyan-400">Pipeline total</span>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-xs text-slate-400 block">In Production</span>
            <span className="text-2xl font-bold text-blue-400 mt-1 block">{inProduction}</span>
            <span className="text-[10px] text-slate-400">Active shooting</span>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-xs text-slate-400 block">Target Assets</span>
            <span className="text-2xl font-bold text-white mt-1 block">{totalTargetAssets}</span>
            <span className="text-[10px] text-emerald-400">High-res photos</span>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-xs text-slate-400 block">Est. Portfolio Value</span>
            <span className="text-2xl font-bold text-emerald-400 mt-1 block">
              ${totalTargetEarnings.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">Annual licensing target</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {["all", "planned", "in_production", "ready_for_review", "submitted", "accepted"].map((statusKey) => (
          <button
            key={statusKey}
            onClick={() => setFilterStatus(statusKey)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              filterStatus === statusKey
                ? "bg-slate-800 text-cyan-400 border border-cyan-500/40 shadow-sm"
                : "bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-white hover:bg-slate-800"
            }`}
          >
            {statusKey === "all" ? "All Shoots" : statusKey.replace(/_/g, " ").toUpperCase()}
          </button>
        ))}
      </div>

      {/* Shoots Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredShoots.map((shoot) => {
          const cfg = STATUS_CONFIG[shoot.status] || STATUS_CONFIG.planned;

          return (
            <div
              key={shoot.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        {shoot.themeCategory}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-blue-500/10 text-blue-300 border border-blue-500/20">
                        {shoot.targetAgency}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-white leading-snug">{shoot.title}</h4>
                  </div>

                  {/* Status Dropdown */}
                  <select
                    value={shoot.status}
                    onChange={(e) => handleUpdateStatus(shoot.id, e.target.value as ShootPlan["status"])}
                    className={`text-[11px] font-bold rounded-lg px-2.5 py-1 border focus:outline-none cursor-pointer ${cfg.color}`}
                  >
                    <option value="planned">Planned</option>
                    <option value="in_production">In Production</option>
                    <option value="ready_for_review">Ready for Review</option>
                    <option value="submitted">Submitted</option>
                    <option value="accepted">Accepted / Earning</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>

                {/* Key metadata */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 text-xs text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Shoot Date:</span>
                    <span className="font-semibold">{shoot.shootDate || "Not set"}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Submission Deadline:</span>
                    <span className="font-semibold text-cyan-300">{shoot.submissionDeadline || "Not set"}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Target Yield:</span>
                    <span className="font-semibold text-emerald-400">
                      {shoot.targetImageCount} imgs (${shoot.estimatedEarnings})
                    </span>
                  </div>
                </div>

                {/* Shot List Checklist */}
                {shoot.shotList && shoot.shotList.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Target Shot List ({shoot.shotList.length}):
                    </span>
                    <div className="space-y-1">
                      {shoot.shotList.map((shot, i) => (
                        <div
                          key={i}
                          className="flex items-start gap-2 text-xs text-slate-300 p-1.5 rounded-lg bg-slate-950/40 border border-slate-800/60"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                          <span className="leading-snug">{shot}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Gear & Location */}
                {(shoot.location || shoot.gearNotes) && (
                  <div className="mt-3 text-xs text-slate-400 space-y-1">
                    {shoot.location && (
                      <p className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="text-slate-300">{shoot.location}</span>
                      </p>
                    )}
                    {shoot.gearNotes && (
                      <p className="flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="text-slate-300">{shoot.gearNotes}</span>
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Card Footer */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono">
                  {shoot.keywords ? shoot.keywords.split(",").length : 0} keywords assigned
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDeleteShoot(shoot.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                    title="Delete shoot plan"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredShoots.length === 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
          <Camera className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h4 className="text-base font-semibold text-white">No Planned Shoots in this filter</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
            Create a new commercial stock shoot or import events from the Global Event Calendar.
          </p>
          <button
            onClick={() => setIsModalOpen(true)}
            className="mt-4 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Plan First Shoot
          </button>
        </div>
      )}

      {/* Plan New Shoot Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <form
            onSubmit={handleCreateShoot}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Camera className="w-5 h-5 text-cyan-400" /> Plan New Stock Photography Shoot
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Shoot Title</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Sustainable Commuting in Metro Area"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Theme Category</label>
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="Lifestyle, Tech, Business..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Target Stock Agency</label>
                <select
                  value={newAgency}
                  onChange={(e) => setNewAgency(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="Adobe Stock">Adobe Stock</option>
                  <option value="Shutterstock">Shutterstock</option>
                  <option value="Getty Images">Getty Images / iStock</option>
                  <option value="Freepik">Freepik</option>
                  <option value="All Agencies">All Major Microstocks</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Shoot Date</label>
                <input
                  type="date"
                  value={newShootDate}
                  onChange={(e) => setNewShootDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Submission Deadline</label>
                <input
                  type="date"
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Target Photo Count</label>
                <input
                  type="number"
                  min="5"
                  max="200"
                  value={newImageCount}
                  onChange={(e) => setNewImageCount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Est. Revenue ($ USD)</label>
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={newEarnings}
                  onChange={(e) => setNewEarnings(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Location & Set</label>
              <input
                type="text"
                value={newLocation}
                onChange={(e) => setNewLocation(e.target.value)}
                placeholder="e.g. Modern co-working hub with natural light"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Gear Notes & Lighting</label>
              <input
                type="text"
                value={newGear}
                onChange={(e) => setNewGear(e.target.value)}
                placeholder="e.g. 50mm f/1.2, 35mm f/1.4, large diffuser scrim"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Shot List (One shot per line)</label>
              <textarea
                rows={3}
                value={newShotList}
                onChange={(e) => setNewShotList(e.target.value)}
                placeholder="1. Over-the-shoulder typing with copy space&#10;2. Smiling portrait at 45 degree angle&#10;3. Flatlay of artisan coffee and blueprint"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-lg shadow-md"
              >
                Save Shoot Plan
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
