"use client";

import React from "react";
import {
  Sparkles,
  ShieldCheck,
  Calendar,
  Layers,
  Settings,
  Camera,
  CheckCircle2,
  FolderGit2,
  SlidersHorizontal,
  Flame,
} from "lucide-react";

export type ActiveTab = "upscaler" | "analyzer" | "calendar" | "planner";

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenSettings: () => void;
}

export function Navbar({ activeTab, setActiveTab, onOpenSettings }: NavbarProps) {
  const navItems = [
    {
      id: "upscaler" as ActiveTab,
      label: "AI Batch Upscaler",
      icon: Sparkles,
      badge: "2x / 4x / 8x",
    },
    {
      id: "analyzer" as ActiveTab,
      label: "Adobe Stock Quality Analyzer",
      icon: ShieldCheck,
      badge: "Rejection Shield",
    },
    {
      id: "calendar" as ActiveTab,
      label: "Global Event Calendar",
      icon: Calendar,
      badge: "Lead Times",
    },
    {
      id: "planner" as ActiveTab,
      label: "Shot Planner & Portfolio",
      icon: Camera,
      badge: null,
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-white">
                  Aperture<span className="text-cyan-400">AI</span>
                </span>
                <span className="px-1.5 py-0.2 text-[9px] font-bold rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase tracking-wider">
                  Pro Contributor
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">
                Adobe Stock & Microstock Production Suite
              </p>
            </div>
          </div>

          {/* Center Tabs Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all relative ${
                    isActive
                      ? "bg-slate-800 text-white shadow-md border border-slate-700/80"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                  }`}
                >
                  <Icon
                    className={`w-3.5 h-3.5 ${
                      isActive ? "text-cyan-400" : "text-slate-400"
                    }`}
                  />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive
                          ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Toolbar */}
          <div className="flex items-center gap-2">
            <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[11px] font-medium text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Adobe Guidelines v2026 Compliant</span>
            </div>

            <button
              onClick={onOpenSettings}
              className="p-2 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors"
              title="Settings & API Keys"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex items-center justify-between overflow-x-auto py-2 border-t border-slate-800/60 gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  isActive ? "bg-slate-800 text-cyan-400" : "text-slate-400 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label.split(" ")[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
