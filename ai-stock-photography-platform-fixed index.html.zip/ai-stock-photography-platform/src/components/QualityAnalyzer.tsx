"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Sparkles,
  Upload,
  ArrowUpRight,
  Sliders,
  Copy,
  Check,
  FileCheck2,
  Eye,
  Maximize2,
  Layers,
  Wand2,
  RefreshCw,
  Info,
} from "lucide-react";
import { AnalysisResult, analyzeImageFile } from "@/lib/quality-analyzer";
import { useToast } from "./Toast";

interface QualityAnalyzerProps {
  initialImageUrl?: string | null;
  initialFileName?: string | null;
  onSendToUpscaler?: (url: string) => void;
}

const SAMPLE_ANALYSIS_PRESETS = [
  {
    name: "Studio Camera Setup",
    url: "https://images.pexels.com/photos/16135635/pexels-photo-16135635.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Good lighting, high sharpness, commercial profile",
  },
  {
    name: "Cozy Coffee Flatlay",
    url: "https://images.pexels.com/photos/8472192/pexels-photo-8472192.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Clean workspace, balanced contrast, negative space",
  },
  {
    name: "Indoor Studio Lighting Test",
    url: "https://images.pexels.com/photos/32092180/pexels-photo-32092180.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Complex shadow transitions and edge lighting",
  },
];

export function QualityAnalyzer({
  initialImageUrl,
  initialFileName,
  onSendToUpscaler,
}: QualityAnalyzerProps) {
  const { toast } = useToast();
  const [currentUrl, setCurrentUrl] = useState<string>(
    initialImageUrl || SAMPLE_ANALYSIS_PRESETS[0].url
  );
  const [currentFileName, setCurrentFileName] = useState<string>(
    initialFileName || "studio_camera_setup.jpg"
  );
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [copiedKeywords, setCopiedKeywords] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const runAnalysis = async (url: string) => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeImageFile(url);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
      toast({
        type: "error",
        title: "Analysis Failed",
        description: "Could not analyze the image. Please verify file format.",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    if (initialImageUrl) {
      setCurrentUrl(initialImageUrl);
      if (initialFileName) setCurrentFileName(initialFileName);
      runAnalysis(initialImageUrl);
    } else {
      runAnalysis(currentUrl);
    }
  }, [initialImageUrl, initialFileName]);

  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({ type: "warning", title: "Invalid File", description: "Please upload an image." });
      return;
    }
    const url = URL.createObjectURL(file);
    setCurrentUrl(url);
    setCurrentFileName(file.name);
    runAnalysis(url);
    toast({
      type: "info",
      title: "Analyzing Stock Asset",
      description: `Performing Adobe Stock technical inspection for ${file.name}...`,
    });
  };

  const handleCopyKeywords = () => {
    if (!analysis) return;
    const kwText = [
      "commercial stock",
      "adobe stock ready",
      "authentic photography",
      "high resolution",
      "clean lighting",
      "studio quality",
      "professional",
      "editorial licensing",
      "negative space",
      "modern concept",
    ].join(", ");

    navigator.clipboard.writeText(kwText);
    setCopiedKeywords(true);
    toast({
      type: "success",
      title: "Keywords Copied!",
      description: "Copied 10 commercial keywords to clipboard.",
    });
    setTimeout(() => setCopiedKeywords(false), 2500);
  };

  // Color helpers based on score
  const getScoreColor = (score: number) => {
    if (score >= 82) return { text: "text-emerald-400", bg: "bg-emerald-500", border: "border-emerald-500/30" };
    if (score >= 68) return { text: "text-amber-400", bg: "bg-amber-500", border: "border-amber-500/30" };
    return { text: "text-rose-400", bg: "bg-rose-500", border: "border-rose-500/30" };
  };

  const overallColors = analysis ? getScoreColor(analysis.overallScore) : { text: "text-cyan-400", bg: "bg-cyan-500", border: "border-cyan-500/30" };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Adobe Stock Quality Validator
              </span>
              <span className="text-xs text-slate-400">Rejection Prevention Diagnostic</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-2">Adobe Stock Quality Analyzer</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Inspect your photos against Adobe Stock’s automated inspection algorithms. Detect noise, chromatic aberration, micro-softness, and JPEG compression artifacts before submission.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Test Sample Stock Images:
            </span>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_ANALYSIS_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrentUrl(preset.url);
                    setCurrentFileName(`${preset.name.toLowerCase().replace(/\s+/g, "_")}.jpg`);
                    runAnalysis(preset.url);
                  }}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700/80 text-slate-200 border border-slate-700 hover:border-emerald-500/50 transition-all flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  {preset.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Analyzer Grid: Left Preview & Uploader, Right Diagnostic Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Image Preview & Dropzone */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            {/* Image Preview Container */}
            <div className="relative bg-slate-950 min-h-[340px] max-h-[460px] flex items-center justify-center p-3 overflow-hidden group">
              <img
                src={currentUrl}
                alt="Analyzing Preview"
                className={`max-w-full max-h-[440px] object-contain rounded-lg transition-all duration-300 ${
                  isAnalyzing ? "opacity-50 blur-sm" : "opacity-100"
                }`}
              />

              {isAnalyzing && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-slate-950/70 backdrop-blur-sm">
                  <div className="w-10 h-10 border-4 border-emerald-500/20 border-t-emerald-400 rounded-full animate-spin" />
                  <span className="text-xs font-semibold text-emerald-300">
                    Scanning pixel gradients & noise frequencies...
                  </span>
                </div>
              )}

              {/* Resolution pill */}
              {analysis && (
                <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-700 text-xs font-mono text-slate-300">
                  {analysis.width} × {analysis.height} • {analysis.megapixels} MP ({analysis.aspectRatio})
                </div>
              )}
            </div>

            {/* Footer with file info and upload button */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/50 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">{currentFileName}</p>
                <p className="text-[11px] text-slate-400">
                  {analysis?.stockChecklist.meetsMinResolution
                    ? "✓ Exceeds 4MP minimum"
                    : "⚠ Under 4MP threshold"}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/tiff"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileUpload(e.target.files[0]);
                    }
                  }}
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" /> Replace Image
                </button>
                <button
                  onClick={() => runAnalysis(currentUrl)}
                  disabled={isAnalyzing}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg border border-slate-700"
                  title="Re-run Analysis"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? "animate-spin" : ""}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Action Card: Send to Upscaler */}
          {analysis && analysis.megapixels < 16 && (
            <div className="p-4 bg-gradient-to-r from-cyan-950/40 to-blue-950/40 border border-cyan-500/30 rounded-2xl flex items-center justify-between gap-3">
              <div>
                <h5 className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                  <Wand2 className="w-4 h-4 text-cyan-400" />
                  Resolution Boost Recommended
                </h5>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Upscale 4x to reach {(analysis.megapixels * 16).toFixed(1)} MP for highest buyer tier.
                </p>
              </div>
              <button
                onClick={() => {
                  if (onSendToUpscaler) {
                    onSendToUpscaler(currentUrl);
                  }
                }}
                className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded-lg shadow-md transition-all shrink-0 flex items-center gap-1"
              >
                Send to 4x Upscaler <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Stock Contributor Compliance Checklist */}
          {analysis && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <FileCheck2 className="w-4 h-4 text-emerald-400" />
                Adobe Stock Contributor Requirements
              </h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Minimum 4.0 Megapixels</span>
                  {analysis.stockChecklist.meetsMinResolution ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Pass ({analysis.megapixels} MP)
                    </span>
                  ) : (
                    <span className="text-rose-400 font-semibold flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" /> Fail ({analysis.megapixels} MP)
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Commercial Standard (&gt;12 MP)</span>
                  {analysis.stockChecklist.recommendedCommercialMP ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Optimal
                    </span>
                  ) : (
                    <span className="text-amber-400 font-semibold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> 4x Upscale Recommended
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">sRGB Color Profile</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> IEC61966-2.1
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Focus & Noise Integrity</span>
                  {analysis.overallScore >= 75 ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Approved
                    </span>
                  ) : (
                    <span className="text-amber-400 font-semibold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Needs Correction
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Approval Predictor Gauge & Diagnostic Breakdown */}
        <div className="lg:col-span-7 space-y-5">
          {/* Main Approval Probability Gauge Card */}
          {analysis && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-center gap-6">
                {/* Circular Score Gauge */}
                <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    {/* Background Track */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="transparent"
                      stroke="#1e293b"
                      strokeWidth="9"
                    />
                    {/* Progress Circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="transparent"
                      stroke="currentColor"
                      strokeWidth="9"
                      strokeDasharray={`${2 * Math.PI * 40}`}
                      strokeDashoffset={`${
                        2 * Math.PI * 40 * (1 - analysis.overallScore / 100)
                      }`}
                      strokeLinecap="round"
                      className={`${overallColors.text} transition-all duration-1000 ease-out`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className={`text-3xl font-black ${overallColors.text}`}>
                      {analysis.overallScore}%
                    </span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      Approval Prob.
                    </span>
                  </div>
                </div>

                {/* Score Details */}
                <div className="flex-1 text-center sm:text-left space-y-2">
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        analysis.probabilityTier === "High"
                          ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                          : analysis.probabilityTier === "Medium"
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      }`}
                    >
                      {analysis.probabilityTier === "High"
                        ? "High Probability of Approval"
                        : analysis.probabilityTier === "Medium"
                        ? "Conditional / Minor Flaws"
                        : "High Risk of Technical Rejection"}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white leading-snug">
                    {analysis.verdict}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Based on algorithmic analysis of shadow noise, chromatic edge fringing, 100% micro-focus, and JPEG quantization block boundaries.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Granular Metrics Deck */}
          {analysis && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  Granular Technical Metrics (100% Zoom Inspection)
                </h4>
                <span className="text-[11px] text-slate-400">Pass benchmark: &ge; 75/100</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.values(analysis.metrics).map((metric) => {
                  const mColors = getScoreColor(metric.score);
                  return (
                    <div
                      key={metric.id}
                      className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="font-semibold text-white">{metric.name}</span>
                          <span className={`font-mono font-bold ${mColors.text}`}>
                            {metric.score}/100
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mb-2">{metric.valueText}</p>
                      </div>

                      <div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-1.5">
                          <div
                            className={`h-full ${mColors.bg} transition-all duration-500`}
                            style={{ width: `${metric.score}%` }}
                          />
                        </div>
                        {metric.warningMessage && (
                          <p className="text-[10px] text-amber-300/90 leading-tight">
                            ⚠ {metric.warningMessage}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Actionable Feedback & Fix Recommendations */}
          {analysis && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Actionable Fixes & Lightroom / Photoshop Sliders
              </h4>

              <div className="space-y-2.5">
                {analysis.actionableFixes.map((fix, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-start gap-3"
                  >
                    <div className="p-1 rounded-md bg-cyan-500/10 text-cyan-400 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-slate-200 leading-relaxed font-medium">{fix}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Keyword Metadata Tagging Assistant */}
              <div className="pt-4 border-t border-slate-800/80">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    Suggested Adobe Stock Keywords (1-Click Paste)
                  </span>
                  <button
                    onClick={handleCopyKeywords}
                    className="px-2.5 py-1 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 hover:border-cyan-500/40 transition-colors flex items-center gap-1"
                  >
                    {copiedKeywords ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy Keywords
                      </>
                    )}
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    "stock photography",
                    "high resolution",
                    "commercial license",
                    "professional lighting",
                    "authentic",
                    "clean composition",
                    "copy space",
                    "editorial quality",
                    "studio portrait",
                    "modern aesthetics",
                  ].map((kw, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded text-[11px] bg-slate-950 text-slate-300 border border-slate-800"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
