"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  Plus,
  Clock,
  Sparkles,
  TrendingUp,
  Globe,
  Tag,
  Check,
  Copy,
  CalendarCheck,
  ArrowRight,
  Flame,
  BookmarkPlus,
  X,
  ListFilter,
  LayoutGrid,
  CalendarDays,
} from "lucide-react";
import { useToast } from "./Toast";

export interface StockEvent {
  id: number;
  name: string;
  date: string; // YYYY-MM-DD
  month: number;
  countryCode: string;
  category: string;
  description: string;
  leadTimeWeeks: number;
  suggestedKeywords: string;
  contentIdeas: string[] | null;
  isPopularStockTheme: boolean;
}

interface EventCalendarProps {
  onAddToShotPlanner?: (event: StockEvent) => void;
}

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const CATEGORIES = [
  { id: "all", label: "All Themes" },
  { id: "commercial", label: "Commercial & Retail" },
  { id: "cultural", label: "Cultural Festivals" },
  { id: "holiday", label: "Global Holidays" },
  { id: "awareness", label: "Health & Awareness" },
  { id: "seasonal", label: "Seasonal & Nature" },
];

const COUNTRIES = [
  { code: "all", label: "All Regions" },
  { code: "GLOBAL", label: "Global / Worldwide" },
  { code: "US", label: "United States" },
  { code: "IN", label: "India" },
  { code: "UK", label: "United Kingdom" },
  { code: "DE", label: "Germany" },
  { code: "JP", label: "Japan" },
];

export function EventCalendar({ onAddToShotPlanner }: EventCalendarProps) {
  const { toast } = useToast();
  const [events, setEvents] = useState<StockEvent[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Filters & State
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1); // 1-12
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCountry, setSelectedCountry] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [viewMode, setViewMode] = useState<"calendar" | "timeline">("calendar");

  // Selected event modal
  const [activeEvent, setActiveEvent] = useState<StockEvent | null>(null);
  const [copiedKw, setCopiedKw] = useState<boolean>(false);

  // Custom Event Modal
  const [isAddingEvent, setIsAddingEvent] = useState<boolean>(false);
  const [newEventName, setNewEventName] = useState("");
  const [newEventDate, setNewEventDate] = useState("2026-06-15");
  const [newEventCategory, setNewEventCategory] = useState("commercial");
  const [newEventCountry, setNewEventCountry] = useState("GLOBAL");
  const [newEventLeadWeeks, setNewEventLeadWeeks] = useState(8);
  const [newEventDesc, setNewEventDesc] = useState("");
  const [newEventKeywords, setNewEventKeywords] = useState("");

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/events");
      if (res.ok) {
        const data = await res.json();
        setEvents(data.events || []);
      }
    } catch (err) {
      console.error(err);
      toast({ type: "error", title: "Failed to load calendar events" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return events.filter((ev) => {
      if (selectedCategory !== "all" && ev.category.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }
      if (selectedCountry !== "all" && ev.countryCode !== "GLOBAL" && ev.countryCode !== selectedCountry) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = ev.name.toLowerCase().includes(q);
        const matchesDesc = ev.description.toLowerCase().includes(q);
        const matchesKw = ev.suggestedKeywords?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesKw) return false;
      }
      return true;
    });
  }, [events, selectedCategory, selectedCountry, searchQuery]);

  // Events in the active month
  const currentMonthEvents = useMemo(() => {
    return filteredEvents.filter((ev) => ev.month === selectedMonth);
  }, [filteredEvents, selectedMonth]);

  // Calculate submission lead-time date
  const getSubmissionDeadline = (eventDateStr: string, leadWeeks: number): { deadlineDate: Date; deadlineStr: string; isUrgent: boolean } => {
    const evDate = new Date(eventDateStr);
    const deadline = new Date(evDate.getTime() - leadWeeks * 7 * 24 * 60 * 60 * 1000);
    const today = new Date();
    const isUrgent = deadline.getTime() <= today.getTime() + 14 * 24 * 60 * 60 * 1000;
    return {
      deadlineDate: deadline,
      deadlineStr: deadline.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      isUrgent,
    };
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventName || !newEventDate) return;

    const monthNum = new Date(newEventDate).getMonth() + 1;

    try {
      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newEventName,
          date: newEventDate,
          month: monthNum,
          countryCode: newEventCountry,
          category: newEventCategory,
          description: newEventDesc,
          leadTimeWeeks: Number(newEventLeadWeeks),
          suggestedKeywords: newEventKeywords,
          contentIdeas: ["Custom planned concept photography shoot"],
        }),
      });

      if (res.ok) {
        toast({ type: "success", title: "Event Added", description: `${newEventName} added to calendar.` });
        setIsAddingEvent(false);
        setNewEventName("");
        fetchEvents();
      }
    } catch {
      toast({ type: "error", title: "Error creating event" });
    }
  };

  const handleAddShootClick = (ev: StockEvent) => {
    if (onAddToShotPlanner) {
      onAddToShotPlanner(ev);
      toast({
        type: "success",
        title: "Added to Shot Planner",
        description: `Created a shoot plan for "${ev.name}" with top Adobe Stock tags.`,
      });
      setActiveEvent(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center gap-1">
                <CalendarDays className="w-3 h-3" /> Adobe Stock Contributor Strategy
              </span>
              <span className="text-xs text-slate-400">Seasonal Demand & Lead-Time Forecast</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-2">Global Event & Content Calendar</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Stock buyers search for holidays and seasonal trends 6 to 10 weeks before the event. Use our strategic lead-time calendar to shoot, upscale, and submit content before peak buyer traffic.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAddingEvent(true)}
              className="px-3.5 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold text-xs rounded-xl shadow-lg flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-4 h-4" /> Add Custom Event
            </button>
          </div>
        </div>

        {/* Filter & View Mode Bar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Search */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search holidays, festivals, themes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category & Region Filters */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>

            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.label}
                </option>
              ))}
            </select>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setViewMode("calendar")}
                className={`p-1.5 rounded transition-colors ${
                  viewMode === "calendar" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
                }`}
                title="Month Calendar View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("timeline")}
                className={`p-1.5 rounded transition-colors ${
                  viewMode === "timeline" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
                }`}
                title="Lead-Time Timeline View"
              >
                <ListFilter className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Month Navigator Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSelectedMonth((m) => (m === 1 ? 12 : m - 1))}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-base font-bold text-white min-w-36 text-center">
            {MONTH_NAMES[selectedMonth - 1]} 2026
          </span>
          <button
            onClick={() => setSelectedMonth((m) => (m === 12 ? 1 : m + 1))}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 12-Month Quick Selector Tabs */}
        <div className="hidden xl:flex items-center gap-1">
          {MONTH_NAMES.map((name, idx) => {
            const mNum = idx + 1;
            const count = filteredEvents.filter((e) => e.month === mNum).length;
            const isSelected = selectedMonth === mNum;
            return (
              <button
                key={mNum}
                onClick={() => setSelectedMonth(mNum)}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all relative ${
                  isSelected
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white hover:bg-slate-800"
                }`}
              >
                {name.slice(0, 3)}
                {count > 0 && (
                  <span
                    className={`ml-1 text-[10px] px-1 rounded-full ${
                      isSelected ? "bg-blue-800 text-blue-100" : "bg-slate-800 text-slate-300"
                    }`}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main View: Calendar Month Grid OR Lead-Time Timeline */}
      {viewMode === "calendar" ? (
        <div className="space-y-4">
          {/* Current Month Events Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentMonthEvents.map((ev) => {
              const { deadlineStr, isUrgent } = getSubmissionDeadline(ev.date, ev.leadTimeWeeks);
              return (
                <div
                  key={ev.id}
                  onClick={() => setActiveEvent(ev)}
                  className="bg-slate-900 border border-slate-800 hover:border-blue-500/40 rounded-2xl p-5 shadow-lg flex flex-col justify-between cursor-pointer transition-all group hover:scale-[1.01]"
                >
                  <div className="space-y-3">
                    {/* Header badges */}
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 uppercase tracking-wide">
                        {ev.category}
                      </span>
                      <span className="text-xs font-mono font-semibold text-slate-300">
                        {new Date(ev.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {ev.name}
                    </h4>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {ev.description}
                    </p>

                    {/* Stock Submission Deadline Alert */}
                    <div
                      className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${
                        isUrgent
                          ? "bg-amber-500/10 border-amber-500/30 text-amber-200"
                          : "bg-slate-950/70 border-slate-800 text-slate-300"
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <Clock className={`w-3.5 h-3.5 ${isUrgent ? "text-amber-400" : "text-cyan-400"}`} />
                        <span className="font-medium">Submit by:</span>
                      </div>
                      <span className="font-bold text-white">{deadlineStr}</span>
                    </div>
                  </div>

                  {/* Footer Details */}
                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-rose-400" /> Peak Stock Demand
                    </span>
                    <span className="text-blue-400 group-hover:translate-x-0.5 transition-transform font-semibold flex items-center gap-1">
                      View Shot Ideas <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {currentMonthEvents.length === 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
              <CalendarIcon className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <h4 className="text-sm font-semibold text-white">No Scheduled Events in {MONTH_NAMES[selectedMonth - 1]}</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                Try selecting another month from the top toolbar or switch category filters.
              </p>
            </div>
          )}
        </div>
      ) : (
        /* Lead-Time Timeline View */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <span>Thematic Event & Date</span>
            <span className="hidden md:inline">Region & Category</span>
            <span>Recommended Stock Lead Time</span>
            <span>Action</span>
          </div>

          <div className="divide-y divide-slate-800/80">
            {filteredEvents.map((ev) => {
              const { deadlineStr, isUrgent } = getSubmissionDeadline(ev.date, ev.leadTimeWeeks);
              return (
                <div
                  key={ev.id}
                  className="p-4 hover:bg-slate-800/40 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{ev.name}</span>
                      <span className="text-slate-400 font-mono">
                        ({new Date(ev.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })})
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] truncate mt-0.5">{ev.description}</p>
                  </div>

                  <div className="hidden md:flex items-center gap-2 text-slate-300">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-medium border border-slate-700">
                      {ev.countryCode}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-medium border border-slate-700">
                      {ev.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div
                      className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 ${
                        isUrgent
                          ? "bg-amber-500/10 border-amber-500/30 text-amber-300"
                          : "bg-slate-950 border-slate-800 text-slate-300"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Upload by {deadlineStr} ({ev.leadTimeWeeks}w lead)</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveEvent(ev)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition-colors"
                    >
                      Details & Keywords
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Event Detail Modal */}
      {activeEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 uppercase">
                    {activeEvent.category}
                  </span>
                  <span className="px-2 py-0.5 text-xs rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {activeEvent.countryCode}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white mt-1.5">{activeEvent.name}</h3>
                <p className="text-xs text-slate-400">
                  Event Date: {new Date(activeEvent.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
                </p>
              </div>
              <button
                onClick={() => setActiveEvent(null)}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Strategic Lead Time Window Alert */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/60 to-cyan-950/60 border border-blue-500/30 space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  Recommended Submission Window
                </span>
                <span className="font-bold text-cyan-300">
                  {activeEvent.leadTimeWeeks} Weeks Prior
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Submit by{" "}
                <strong className="text-white">
                  {getSubmissionDeadline(activeEvent.date, activeEvent.leadTimeWeeks).deadlineStr}
                </strong>{" "}
                to give Adobe Stock algorithms enough time to index, categorize, and rank your content before peak buyer licensing surges.
              </p>
            </div>

            {/* Content Ideas / What to Shoot */}
            <div className="space-y-2">
              <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Commercial Shot List & Concepts to Capture:
              </h5>
              <div className="space-y-1.5">
                {(activeEvent.contentIdeas || [
                  "Authentic human expressions with diverse casting",
                  "Minimalist flatlays with high copy space for marketing text",
                  "Contemporary natural lighting setups with clean background blur",
                ]).map((idea, i) => (
                  <div key={i} className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs text-slate-300 flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                    <span>{idea}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Adobe Stock Search Keywords */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-cyan-400" />
                  High-Ranking Adobe Stock Keywords:
                </h5>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(activeEvent.suggestedKeywords);
                    setCopiedKw(true);
                    toast({ type: "success", title: "Keywords copied to clipboard" });
                    setTimeout(() => setCopiedKw(false), 2000);
                  }}
                  className="px-2.5 py-1 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 flex items-center gap-1"
                >
                  {copiedKw ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedKw ? "Copied" : "Copy Tags"}
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 font-mono leading-relaxed">
                {activeEvent.suggestedKeywords}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                onClick={() => setActiveEvent(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
              >
                Close
              </button>
              <button
                onClick={() => handleAddShootClick(activeEvent)}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 transition-all"
              >
                <BookmarkPlus className="w-4 h-4" />
                Add to My Shot Planner
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Event Modal */}
      {isAddingEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <form
            onSubmit={handleCreateEvent}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Add Custom Contributor Milestone</h3>
              <button
                type="button"
                onClick={() => setIsAddingEvent(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Event Name</label>
              <input
                type="text"
                required
                value={newEventName}
                onChange={(e) => setNewEventName(e.target.value)}
                placeholder="e.g. Summer Olympic Games or Local Food Festival"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Event Date</label>
                <input
                  type="date"
                  required
                  value={newEventDate}
                  onChange={(e) => setNewEventDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Lead Time (Weeks)</label>
                <input
                  type="number"
                  min="2"
                  max="16"
                  value={newEventLeadWeeks}
                  onChange={(e) => setNewEventLeadWeeks(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Category</label>
                <select
                  value={newEventCategory}
                  onChange={(e) => setNewEventCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="commercial">Commercial</option>
                  <option value="cultural">Cultural</option>
                  <option value="holiday">Holiday</option>
                  <option value="awareness">Awareness</option>
                  <option value="seasonal">Seasonal</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">Region</label>
                <select
                  value={newEventCountry}
                  onChange={(e) => setNewEventCountry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="GLOBAL">Global</option>
                  <option value="US">United States</option>
                  <option value="IN">India</option>
                  <option value="UK">United Kingdom</option>
                  <option value="JP">Japan</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Keywords</label>
              <input
                type="text"
                value={newEventKeywords}
                onChange={(e) => setNewEventKeywords(e.target.value)}
                placeholder="festival, street food, authentic, outdoor"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Description & Strategy</label>
              <textarea
                rows={2}
                value={newEventDesc}
                onChange={(e) => setNewEventDesc(e.target.value)}
                placeholder="Visual concepts, model release requirements, target buyer demographics..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddingEvent(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg"
              >
                Save Event
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
