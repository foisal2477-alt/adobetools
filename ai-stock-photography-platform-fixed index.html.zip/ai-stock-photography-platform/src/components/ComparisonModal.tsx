"use client";

import React, { useState, useRef, useEffect } from "react";
import { X, ZoomIn, ZoomOut, RotateCcw, Download, Sparkles, Check, SlidersHorizontal, Eye } from "lucide-react";

interface ComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalUrl: string;
  upscaledUrl: string;
  fileName: string;
  originalWidth: number;
  originalHeight: number;
  upscaledWidth: number;
  upscaledHeight: number;
  scaleFactor: number;
  modelName: string;
  qualityScore?: number;
}

export function ComparisonModal({
  isOpen,
  onClose,
  originalUrl,
  upscaledUrl,
  fileName,
  originalWidth,
  originalHeight,
  upscaledWidth,
  upscaledHeight,
  scaleFactor,
  modelName,
  qualityScore = 92,
}: ComparisonModalProps) {
  const [sliderPos, setSliderPos] = useState(50); // 0 to 100%
  const [zoom, setZoom] = useState(1); // 1 to 4
  const [viewMode, setViewMode] = useState<"split" | "sideBySide">("split");
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (isOpen) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    handlePointerMove(e);
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = Math.round((x / rect.width) * 100);
    setSliderPos(percent);
  };

  const handleDownloadUpscaled = () => {
    const a = document.createElement("a");
    a.href = upscaledUrl;
    a.download = `${fileName.replace(/\.[^/.]+$/, "")}_${scaleFactor}x_upscaled.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="flex flex-col w-full max-w-6xl h-[90vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-white text-base truncate max-w-md">{fileName}</h3>
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {scaleFactor}x AI Upscaled
                </span>
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Score {qualityScore}%
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Original: {originalWidth}×{originalHeight} ({((originalWidth * originalHeight) / 1000000).toFixed(1)} MP) → Upscaled: {upscaledWidth}×{upscaledHeight} ({((upscaledWidth * upscaledHeight) / 1000000).toFixed(1)} MP) • {modelName}
              </p>
            </div>
          </div>

          {/* Controls & Close */}
          <div className="flex items-center gap-3">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-800 p-1 rounded-lg border border-slate-700 text-xs">
              <button
                onClick={() => setViewMode("split")}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  viewMode === "split"
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Split Slider
              </button>
              <button
                onClick={() => setViewMode("sideBySide")}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  viewMode === "sideBySide"
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Side-by-Side
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700">
              <button
                onClick={() => setZoom((z) => Math.max(1, z - 0.5))}
                disabled={zoom <= 1}
                className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono font-medium text-slate-300 px-1">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(3, z + 0.5))}
                disabled={zoom >= 3}
                className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              {zoom > 1 && (
                <button
                  onClick={() => setZoom(1)}
                  className="p-1.5 text-slate-400 hover:text-cyan-400"
                  title="Reset Zoom"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Download Button */}
            <button
              onClick={handleDownloadUpscaled}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold rounded-lg shadow-md transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Download JPEG
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewport Area */}
        <div className="flex-1 relative overflow-auto bg-slate-950 flex items-center justify-center p-4 select-none">
          {viewMode === "split" ? (
            <div
              ref={containerRef}
              onPointerDown={handlePointerDown}
              onPointerMove={isDragging ? handlePointerMove : undefined}
              onPointerUp={handlePointerUp}
              className="relative max-w-full max-h-full cursor-ew-resize overflow-hidden rounded-xl border border-slate-700/60 shadow-2xl bg-slate-900"
              style={{
                transform: `scale(${zoom})`,
                transformOrigin: "center center",
                transition: isDragging ? "none" : "transform 0.2s ease-out",
              }}
            >
              {/* Upscaled Background Layer (Right Side) */}
              <img
                src={upscaledUrl}
                alt="Upscaled Preview"
                className="block max-h-[68vh] w-auto object-contain pointer-events-none select-none"
              />

              {/* Original Clipped Layer (Left Side) */}
              <div
                className="absolute inset-0 overflow-hidden pointer-events-none"
                style={{ width: `${sliderPos}%` }}
              >
                <img
                  src={originalUrl}
                  alt="Original Preview"
                  className="block max-h-[68vh] w-auto max-w-none object-contain select-none"
                  style={{
                    width: containerRef.current ? `${containerRef.current.offsetWidth}px` : "100%",
                    height: "100%",
                  }}
                />
              </div>

              {/* Slider Divider Line */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.8)] pointer-events-none z-20"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-900 border-2 border-cyan-400 text-cyan-300 flex items-center justify-center shadow-lg">
                  <SlidersHorizontal className="w-3.5 h-3.5 rotate-90" />
                </div>
              </div>

              {/* Labels */}
              <div className="absolute top-4 left-4 z-20 px-2.5 py-1 rounded bg-slate-950/80 backdrop-blur-sm border border-slate-700 text-xs font-semibold text-slate-300 pointer-events-none">
                Original ({originalWidth}×{originalHeight})
              </div>
              <div className="absolute top-4 right-4 z-20 px-2.5 py-1 rounded bg-slate-950/80 backdrop-blur-sm border border-cyan-500/40 text-xs font-semibold text-cyan-300 pointer-events-none flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                {scaleFactor}x Upscaled ({upscaledWidth}×{upscaledHeight})
              </div>
            </div>
          ) : (
            <div
              className="grid grid-cols-2 gap-4 w-full h-full p-2"
              style={{
                transform: `scale(${zoom})`,
                transformOrigin: "center center",
              }}
            >
              {/* Original */}
              <div className="relative flex flex-col items-center justify-center bg-slate-900/80 rounded-xl border border-slate-800 p-2 overflow-hidden">
                <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded bg-slate-950/80 border border-slate-700 text-xs font-semibold text-slate-300">
                  Before: {originalWidth}×{originalHeight}
                </div>
                <img
                  src={originalUrl}
                  alt="Original"
                  className="max-h-[62vh] max-w-full object-contain rounded"
                />
              </div>

              {/* Upscaled */}
              <div className="relative flex flex-col items-center justify-center bg-slate-900/80 rounded-xl border border-cyan-500/30 p-2 overflow-hidden">
                <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded bg-slate-950/80 border border-cyan-500/40 text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  After: {scaleFactor}x Super-Res ({upscaledWidth}×{upscaledHeight})
                </div>
                <img
                  src={upscaledUrl}
                  alt="Upscaled"
                  className="max-h-[62vh] max-w-full object-contain rounded"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950/80 text-xs text-slate-400">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
              Pixel Integrity: 100% Artifact-free interpolation
            </span>
            <span>Target Market: Adobe Stock 300 DPI Commercial Print</span>
            <span>Color Profile: sRGB IEC61966-2.1</span>
          </div>
          <div className="text-slate-400">
            Drag the cyan slider or switch view modes to inspect fine textures and eyelash/fabric detail.
          </div>
        </div>
      </div>
    </div>
  );
}
