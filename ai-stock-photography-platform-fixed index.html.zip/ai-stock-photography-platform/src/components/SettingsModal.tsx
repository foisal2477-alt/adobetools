"use client";

import React, { useState, useEffect } from "react";
import { X, Settings, Key, Sparkles, Sliders, Save, Check, ExternalLink, ShieldCheck } from "lucide-react";
import { useToast } from "./Toast";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [contributorName, setContributorName] = useState("Adobe Stock Pro Contributor");
  const [replicateKey, setReplicateKey] = useState("");
  const [stabilityKey, setStabilityKey] = useState("");
  const [hasReplicateKey, setHasReplicateKey] = useState(false);
  const [hasStabilityKey, setHasStabilityKey] = useState(false);

  const [defaultScale, setDefaultScale] = useState(4);
  const [defaultModel, setDefaultModel] = useState("Real-ESRGAN v3 Photo");
  const [autoDenoise, setAutoDenoise] = useState(true);
  const [autoSharpen, setAutoSharpen] = useState(true);
  const [targetColorSpace, setTargetColorSpace] = useState("sRGB");
  const [exportFormat, setExportFormat] = useState("JPEG (High 95%)");

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      fetch("/api/settings")
        .then((res) => res.json())
        .then((data) => {
          if (data.settings) {
            setContributorName(data.settings.contributorName || "Adobe Stock Contributor");
            setHasReplicateKey(Boolean(data.settings.hasReplicateKey));
            setHasStabilityKey(Boolean(data.settings.hasStabilityKey));
            setDefaultScale(data.settings.defaultScaleFactor || 4);
            setDefaultModel(data.settings.defaultModel || "Real-ESRGAN v3 Photo");
            setAutoDenoise(data.settings.autoDenoise ?? true);
            setAutoSharpen(data.settings.autoSharpen ?? true);
            setTargetColorSpace(data.settings.targetColorSpace || "sRGB");
            setExportFormat(data.settings.exportFormat || "JPEG (High 95%)");
          }
        })
        .finally(() => setLoading(false));
    }
  }, [isOpen]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        contributorName,
        defaultScaleFactor: defaultScale,
        defaultModel,
        autoDenoise,
        autoSharpen,
        targetColorSpace,
        exportFormat,
      };

      if (replicateKey) payload.replicateApiKey = replicateKey;
      if (stabilityKey) payload.stabilityApiKey = stabilityKey;

      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        toast({
          type: "success",
          title: "Settings Saved",
          description: "Your AI upscaling and stock contributor preferences are updated.",
        });
        setReplicateKey("");
        setStabilityKey("");
        onClose();
      }
    } catch {
      toast({ type: "error", title: "Failed to save settings" });
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Contributor & AI Engine Settings</h3>
              <p className="text-xs text-slate-400">Configure upscale parameters, API keys, and stock guidelines</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          {/* Contributor Profile */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Contributor Handle / Studio</label>
            <input
              type="text"
              value={contributorName}
              onChange={(e) => setContributorName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* AI API Integrations */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Key className="w-4 h-4 text-cyan-400" />
                External AI Upscaling APIs (Optional)
              </span>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Built-in Neural Engine Active
              </span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              ApertureAI includes high-performance client & server subpixel interpolation. You can optionally supply your own Replicate or Stability AI token for cloud GPU processing.
            </p>

            <div className="space-y-2">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-300">Replicate API Token (r8_...)</span>
                  {hasReplicateKey && (
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Token Configured
                    </span>
                  )}
                </div>
                <input
                  type="password"
                  value={replicateKey}
                  onChange={(e) => setReplicateKey(e.target.value)}
                  placeholder={hasReplicateKey ? "•••••••••••••••• (Leave blank to keep)" : "Enter r8_... token"}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-300">Stability AI Key (sk-...)</span>
                  {hasStabilityKey && (
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Token Configured
                    </span>
                  )}
                </div>
                <input
                  type="password"
                  value={stabilityKey}
                  onChange={(e) => setStabilityKey(e.target.value)}
                  placeholder={hasStabilityKey ? "•••••••••••••••• (Leave blank to keep)" : "Enter sk-... token"}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Upscale Defaults */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Default Scale Factor</label>
              <select
                value={defaultScale}
                onChange={(e) => setDefaultScale(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value={2}>2x Super-Resolution</option>
                <option value={4}>4x Ultra-Resolution (Recommended)</option>
                <option value={8}>8x Extreme Megapixel</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Default Model</label>
              <select
                value={defaultModel}
                onChange={(e) => setDefaultModel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Real-ESRGAN v3 Photo">Real-ESRGAN v3 Photo</option>
                <option value="Topaz Detail Boost">Topaz Detail Boost</option>
                <option value="Adobe Stock Super-Res Pro">Adobe Stock Super-Res Pro</option>
                <option value="Clarity De-Noise Engine">Clarity De-Noise Engine</option>
              </select>
            </div>
          </div>

          {/* Quality toggles */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-white block">Post-Processing Quality Filters:</span>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Auto Bilateral Shadow De-Noising</span>
              <input
                type="checkbox"
                checked={autoDenoise}
                onChange={(e) => setAutoDenoise(e.target.checked)}
                className="rounded text-cyan-500 w-4 h-4 bg-slate-800 border-slate-700"
              />
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Edge-Preserving Unsharp Filter</span>
              <input
                type="checkbox"
                checked={autoSharpen}
                onChange={(e) => setAutoSharpen(e.target.checked)}
                className="rounded text-cyan-500 w-4 h-4 bg-slate-800 border-slate-700"
              />
            </div>
          </div>

          {/* Export formats */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Color Space</label>
              <select
                value={targetColorSpace}
                onChange={(e) => setTargetColorSpace(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="sRGB">sRGB (Adobe Stock Mandatory)</option>
                <option value="Adobe RGB (1998)">Adobe RGB (1998)</option>
                <option value="Display P3">Display P3</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Export Format</label>
              <select
                value={exportFormat}
                onChange={(e) => setExportFormat(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="JPEG (High 95%)">JPEG (High 95%)</option>
                <option value="PNG (Lossless 24-bit)">PNG (Lossless 24-bit)</option>
                <option value="WebP (98%)">WebP (98%)</option>
              </select>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-lg shadow-md flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? "Saving..." : "Save Preferences"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
