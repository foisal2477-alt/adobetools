"use client";

import React, { useState, useRef, useCallback } from "react";
import {
  Upload,
  Sparkles,
  Download,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  Play,
  Layers,
  ArrowRight,
  Maximize2,
  FileArchive,
  Image as ImageIcon,
  Check,
  Cpu,
  FileCheck2,
} from "lucide-react";
import { UpscaleJob, upscaleImage, downloadBatchZip } from "@/lib/image-processor";
import { aiUpscaleImage, AI_MODELS, AIModelId } from "@/lib/ai-upscaler";
import { ComparisonModal } from "./ComparisonModal";
import { useToast } from "./Toast";

const FAST_PREVIEW_MODEL = "fast-preview" as const;
type ModelSelection = AIModelId | typeof FAST_PREVIEW_MODEL;

// Sample test photos from our curated stock collection
const SAMPLE_PRESETS = [
  {
    name: "Studio Photographer Portrait",
    url: "https://images.pexels.com/photos/16135635/pexels-photo-16135635.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    width: 1200,
    height: 627,
    sizeKb: 145,
  },
  {
    name: "Minimalist Workspace Flatlay",
    url: "https://images.pexels.com/photos/8472192/pexels-photo-8472192.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    width: 1200,
    height: 627,
    sizeKb: 168,
  },
  {
    name: "Camera Gear Studio Close-up",
    url: "https://images.pexels.com/photos/16135552/pexels-photo-16135552.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    width: 1200,
    height: 627,
    sizeKb: 130,
  },
];

interface BatchUpscalerProps {
  onSendToAnalyzer?: (url: string, name: string) => void;
}

export function BatchUpscaler({ onSendToAnalyzer }: BatchUpscalerProps) {
  const { toast } = useToast();
  const [jobs, setJobs] = useState<UpscaleJob[]>([]);
  const [scaleFactor, setScaleFactor] = useState<2 | 4 | 8>(4);
  const [selectedModel, setSelectedModel] = useState<ModelSelection>(AI_MODELS[0].id);
  const [autoDenoise, setAutoDenoise] = useState<boolean>(true);
  const [autoSharpen, setAutoSharpen] = useState<boolean>(true);
  const [isProcessingBatch, setIsProcessingBatch] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [zipProgress, setZipProgress] = useState<number>(0);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);

  // Active Comparison Modal state
  const [activeCompareJob, setActiveCompareJob] = useState<UpscaleJob | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle file additions
  const handleAddFiles = useCallback(
    (files: FileList | File[]) => {
      const newJobs: UpscaleJob[] = [];

      Array.from(files).forEach((file) => {
        if (!file.type.startsWith("image/")) {
          toast({
            type: "warning",
            title: "Skipped non-image file",
            description: `${file.name} is not a valid JPG/PNG/WebP image.`,
          });
          return;
        }

        const id = Math.random().toString(36).substring(2, 10);
        const url = URL.createObjectURL(file);

        // Read image dimensions
        const img = new Image();
        img.src = url;
        img.onload = () => {
          setJobs((prev) =>
            prev.map((j) =>
              j.id === id
                ? {
                    ...j,
                    originalWidth: img.naturalWidth || 1920,
                    originalHeight: img.naturalHeight || 1080,
                    upscaledWidth: (img.naturalWidth || 1920) * scaleFactor,
                    upscaledHeight: (img.naturalHeight || 1080) * scaleFactor,
                  }
                : j
            )
          );
        };

        newJobs.push({
          id,
          file,
          originalUrl: url,
          fileName: file.name,
          fileSize: file.size,
          originalWidth: 1200, // placeholder updated on load
          originalHeight: 800,
          scaleFactor,
          aiModel: selectedModel,
          status: "queued",
          progress: 0,
          stepMessage: "Waiting in queue...",
          upscaledUrl: null,
          upscaledBlob: null,
          upscaledWidth: 1200 * scaleFactor,
          upscaledHeight: 800 * scaleFactor,
          upscaledSizeKb: 0,
          qualityScore: 88,
        });
      });

      if (newJobs.length > 0) {
        setJobs((prev) => [...prev, ...newJobs]);
        toast({
          type: "success",
          title: `Added ${newJobs.length} image${newJobs.length > 1 ? "s" : ""} to queue`,
          description: "Ready to upscale for Adobe Stock submission.",
        });
      }
    },
    [scaleFactor, selectedModel, toast]
  );

  // Add preset sample
  const handleAddPreset = (preset: (typeof SAMPLE_PRESETS)[0]) => {
    const id = Math.random().toString(36).substring(2, 10);
    const newJob: UpscaleJob = {
      id,
      file: null,
      originalUrl: preset.url,
      fileName: `${preset.name.toLowerCase().replace(/\s+/g, "_")}.jpg`,
      fileSize: preset.sizeKb * 1024,
      originalWidth: preset.width,
      originalHeight: preset.height,
      scaleFactor,
      aiModel: selectedModel,
      status: "queued",
      progress: 0,
      stepMessage: "Ready to process preset",
      upscaledUrl: null,
      upscaledBlob: null,
      upscaledWidth: preset.width * scaleFactor,
      upscaledHeight: preset.height * scaleFactor,
      upscaledSizeKb: 0,
      qualityScore: 90,
    };
    setJobs((prev) => [...prev, newJob]);
    toast({
      type: "info",
      title: "Sample Stock Image Loaded",
      description: `Loaded "${preset.name}" (${preset.width}x${preset.height})`,
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleAddFiles(e.dataTransfer.files);
    }
  };

  // Update scale factor for all queued items
  const handleScaleFactorChange = (factor: 2 | 4 | 8) => {
    setScaleFactor(factor);
    setJobs((prev) =>
      prev.map((j) =>
        j.status === "queued"
          ? {
              ...j,
              scaleFactor: factor,
              upscaledWidth: j.originalWidth * factor,
              upscaledHeight: j.originalHeight * factor,
            }
          : j
      )
    );
  };

  // Process a single job
  const processJob = async (jobId: string) => {
    const job = jobs.find((j) => j.id === jobId);
    if (!job) return;

    setJobs((prev) =>
      prev.map((j) =>
        j.id === jobId ? { ...j, status: "processing", progress: 10, stepMessage: "Preparing canvas..." } : j
      )
    );

    try {
      const onProgress = (p: number, step: string) => {
        setJobs((prev) =>
          prev.map((j) => (j.id === jobId ? { ...j, progress: p, stepMessage: step } : j))
        );
      };

      const result =
        selectedModel === FAST_PREVIEW_MODEL
          ? await upscaleImage(job.originalUrl, {
              scaleFactor: job.scaleFactor,
              model: "Fast Preview (resize only, no AI)",
              denoise: autoDenoise,
              sharpen: autoSharpen,
              exportFormat: "image/jpeg",
              quality: 0.95,
              onProgress,
            })
          : await aiUpscaleImage(job.originalUrl, {
              model: selectedModel,
              targetScale: job.scaleFactor,
              exportFormat: "image/jpeg",
              quality: 0.95,
              onProgress,
            });

      setJobs((prev) =>
        prev.map((j) =>
          j.id === jobId
            ? {
                ...j,
                status: "completed",
                progress: 100,
                stepMessage: "Completed & Ready",
                upscaledUrl: result.upscaledUrl,
                upscaledBlob: result.blob,
                upscaledWidth: result.width,
                upscaledHeight: result.height,
                upscaledSizeKb: result.sizeKb,
                qualityScore: result.qualityScore,
              }
            : j
        )
      );

      // Save to server history in background
      fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: job.fileName,
          originalWidth: job.originalWidth,
          originalHeight: job.originalHeight,
          upscaledWidth: result.width,
          upscaledHeight: result.height,
          scaleFactor: job.scaleFactor,
          aiModel: selectedModel,
          qualityScore: result.qualityScore,
          fileSizeKb: result.sizeKb,
          status: "completed",
        }),
      }).catch(() => {});
    } catch (err) {
      console.error(err);
      setJobs((prev) =>
        prev.map((j) =>
          j.id === jobId
            ? {
                ...j,
                status: "error",
                stepMessage: "Processing failed",
                error: (err as Error).message,
              }
            : j
        )
      );
    }
  };

  // Run all queued batch jobs sequentially
  const handleStartBatch = async () => {
    const queuedJobs = jobs.filter((j) => j.status === "queued");
    if (queuedJobs.length === 0) {
      toast({
        type: "warning",
        title: "No queued images",
        description: "Upload images or add sample stock photos to process.",
      });
      return;
    }

    setIsProcessingBatch(true);
    toast({
      type: "info",
      title: "Batch Processing Started",
      description: `Processing ${queuedJobs.length} images with ${selectedModel}...`,
    });

    for (const job of queuedJobs) {
      await processJob(job.id);
    }

    setIsProcessingBatch(false);
    toast({
      type: "success",
      title: "Batch Upscaling Complete!",
      description: "All images are processed and ready for Adobe Stock submission.",
    });
  };

  // Batch download ZIP
  const handleDownloadZip = async () => {
    const completed = jobs.filter((j) => j.status === "completed" && j.upscaledBlob);
    if (completed.length === 0) {
      toast({
        type: "warning",
        title: "No completed images",
        description: "Upscale images before downloading batch ZIP archive.",
      });
      return;
    }

    setIsZipping(true);
    setZipProgress(10);
    try {
      await downloadBatchZip(jobs, (p) => setZipProgress(p));
      toast({
        type: "success",
        title: "Batch ZIP Downloaded",
        description: `Exported ${completed.length} images + Adobe Stock metadata CSV.`,
      });
    } catch (err) {
      toast({
        type: "error",
        title: "Failed to create ZIP",
        description: (err as Error).message,
      });
    } finally {
      setIsZipping(false);
      setZipProgress(0);
    }
  };

  // Clear finished or all
  const handleClearAll = () => {
    setJobs([]);
    toast({ type: "info", title: "Batch queue cleared" });
  };

  // Stats calculation
  const totalCount = jobs.length;
  const completedCount = jobs.filter((j) => j.status === "completed").length;
  const processingCount = jobs.filter((j) => j.status === "processing").length;
  const masterProgress =
    totalCount > 0
      ? Math.round(
          jobs.reduce((acc, j) => acc + (j.status === "completed" ? 100 : j.progress), 0) /
            totalCount
        )
      : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Deck */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Adobe Stock Ultra-Res Engine
              </span>
              <span className="text-xs text-slate-400">Zero-artifact detail synthesis</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-2">AI Batch Image Upscaler</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Upscale microstock photos to 2x, 4x, or 8x resolution (up to 100+ Megapixels) while eliminating JPEG quantization artifacts, sensor noise, and lens soft-edges.
            </p>
          </div>

          {/* Preset Buttons */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Quick Test With Stock Presets:
            </span>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAddPreset(preset)}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700/80 text-slate-200 border border-slate-700 hover:border-cyan-500/50 transition-all flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                  {preset.name.split(" ")[0]} ({preset.width}p)
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Configuration Toolbar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Scale Factor Selector */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <label className="text-xs font-medium text-slate-400 block mb-2">
              Super-Resolution Scale:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {([2, 4, 8] as const).map((factor) => (
                <button
                  key={factor}
                  onClick={() => handleScaleFactorChange(factor)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                    scaleFactor === factor
                      ? "bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                      : "bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white"
                  }`}
                >
                  {factor}x
                  <span className="block text-[10px] font-normal opacity-80">
                    {factor === 2 ? "+4x Pixels" : factor === 4 ? "+16x Pixels" : "+64x Pixels"}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* AI Model Architecture */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <label className="text-xs font-medium text-slate-400 block mb-2">
              Neural Processing Architecture:
            </label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value as ModelSelection)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
            >
              {AI_MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
              <option value={FAST_PREVIEW_MODEL}>Fast Preview (resize only, no AI, instant)</option>
            </select>
            <span className="text-[10px] text-slate-400 mt-1 block">
              {selectedModel === FAST_PREVIEW_MODEL
                ? "Plain resize — useful for quick layout checks, not for final delivery."
                : AI_MODELS.find((m) => m.id === selectedModel)?.description}
            </span>
          </div>

          {/* Quality Options */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <label className="text-xs font-medium text-slate-400 block mb-2">
              Fast Preview Options:
            </label>
            <div className={`space-y-1.5 text-xs ${selectedModel !== FAST_PREVIEW_MODEL ? "opacity-40" : ""}`}>
              <label className="flex items-center gap-2 text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoDenoise}
                  disabled={selectedModel !== FAST_PREVIEW_MODEL}
                  onChange={(e) => setAutoDenoise(e.target.checked)}
                  className="rounded text-cyan-500 focus:ring-0 bg-slate-800 border-slate-700 w-3.5 h-3.5"
                />
                <span>Denoise threshold (unsharp mask)</span>
              </label>
              <label className="flex items-center gap-2 text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoSharpen}
                  disabled={selectedModel !== FAST_PREVIEW_MODEL}
                  onChange={(e) => setAutoSharpen(e.target.checked)}
                  className="rounded text-cyan-500 focus:ring-0 bg-slate-800 border-slate-700 w-3.5 h-3.5"
                />
                <span>Edge sharpen pass</span>
              </label>
              <p className="text-[10px] text-slate-500 pt-1">
                Only applies to Fast Preview. The Real-ESRGAN models run a real neural network and don&apos;t use these toggles.
              </p>
            </div>
          </div>

          {/* Master Action Trigger */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Queue Status:</span>
              <span className="font-semibold text-cyan-400">
                {jobs.length} files ({completedCount} done)
              </span>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={handleStartBatch}
                disabled={isProcessingBatch || jobs.filter((j) => j.status === "queued").length === 0}
                className="flex-1 py-2 px-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-slate-950 font-bold text-xs rounded-lg shadow-lg flex items-center justify-center gap-1.5 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                {isProcessingBatch ? "Processing..." : `Upscale All (${scaleFactor}x)`}
              </button>
              {completedCount > 0 && (
                <button
                  onClick={handleDownloadZip}
                  disabled={isZipping}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-all"
                  title="Download Batch ZIP (Images + Adobe Stock CSV)"
                >
                  <FileArchive className="w-4 h-4 text-cyan-400" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
          isDraggingOver
            ? "border-cyan-400 bg-cyan-950/20 shadow-[0_0_25px_rgba(6,182,212,0.2)]"
            : "border-slate-700 hover:border-slate-600 bg-slate-900/40 hover:bg-slate-900/60"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,image/tiff"
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              handleAddFiles(e.target.files);
            }
          }}
        />

        <div className="flex flex-col items-center justify-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center shadow-inner">
            <Upload className="w-7 h-7" />
          </div>
          <div>
            <h4 className="text-base font-semibold text-white">
              Drag & Drop your stock photos here
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Supports batch upload: JPEG, PNG, WebP, TIFF (up to 100MB per file)
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400 bg-slate-800/80 px-4 py-1.5 rounded-full border border-slate-700/60">
            <span>✓ Multi-file batch queue</span>
            <span>✓ 2x / 4x / 8x Super-Resolution</span>
            <span>✓ Auto sRGB Color Profile</span>
          </div>
        </div>
      </div>

      {/* Master Progress Bar (when jobs exist) */}
      {jobs.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white">Batch Queue Progress</span>
              <span className="text-slate-400">
                ({completedCount} of {totalCount} completed • {masterProgress}%)
              </span>
            </div>
            <div className="flex items-center gap-3">
              {completedCount > 0 && (
                <button
                  onClick={handleDownloadZip}
                  disabled={isZipping}
                  className="flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300"
                >
                  <Download className="w-3.5 h-3.5" />
                  {isZipping ? `Archiving ${zipProgress}%...` : "Download Batch ZIP + CSV"}
                </button>
              )}
              <button
                onClick={handleClearAll}
                className="text-xs text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" /> Clear Queue
              </button>
            </div>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 transition-all duration-300"
              style={{ width: `${masterProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Batch Cards Grid */}
      {jobs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.map((job) => {
            const origMp = ((job.originalWidth * job.originalHeight) / 1000000).toFixed(1);
            const upscaledMp = ((job.upscaledWidth * job.upscaledHeight) / 1000000).toFixed(1);

            return (
              <div
                key={job.id}
                className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg flex flex-col group hover:border-slate-700 transition-all"
              >
                {/* Thumbnail Header */}
                <div className="relative h-44 bg-slate-950 overflow-hidden flex items-center justify-center">
                  <img
                    src={job.upscaledUrl || job.originalUrl}
                    alt={job.fileName}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

                  {/* Status Badge */}
                  <div className="absolute top-3 left-3">
                    {job.status === "completed" && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 backdrop-blur-sm">
                        <CheckCircle2 className="w-3 h-3" /> {job.scaleFactor}x Upscaled
                      </span>
                    )}
                    {job.status === "processing" && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center gap-1 backdrop-blur-sm animate-pulse">
                        <Cpu className="w-3 h-3 animate-spin" /> Processing {job.progress}%
                      </span>
                    )}
                    {job.status === "queued" && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800/80 text-slate-300 border border-slate-700 backdrop-blur-sm">
                        Queued for {job.scaleFactor}x
                      </span>
                    )}
                    {job.status === "error" && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1 backdrop-blur-sm">
                        <AlertCircle className="w-3 h-3" /> Error
                      </span>
                    )}
                  </div>

                  {/* Resolution pill */}
                  <div className="absolute bottom-2 left-3 text-[11px] text-slate-300 font-mono flex items-center gap-1.5">
                    <span>{job.originalWidth}×{job.originalHeight}</span>
                    <ArrowRight className="w-3 h-3 text-cyan-400" />
                    <span className="font-bold text-cyan-300">{job.upscaledWidth}×{job.upscaledHeight}</span>
                    <span className="text-slate-400">({upscaledMp} MP)</span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h5 className="text-xs font-semibold text-white truncate" title={job.fileName}>
                      {job.fileName}
                    </h5>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Model: {job.aiModel} • Adobe Stock Target: {upscaledMp} MP
                    </p>
                  </div>

                  {/* Individual Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="truncate">{job.stepMessage}</span>
                      <span className="font-mono text-cyan-400">{job.progress}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-500 transition-all duration-200"
                        style={{ width: `${job.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    {job.status === "completed" && job.upscaledUrl ? (
                      <>
                        <button
                          onClick={() => setActiveCompareJob(job)}
                          className="flex-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors border border-slate-700 hover:border-cyan-500/40"
                          title="Compare 100% Zoom Before & After"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Compare
                        </button>
                        <button
                          onClick={() => {
                            if (onSendToAnalyzer && job.upscaledUrl) {
                              onSendToAnalyzer(job.upscaledUrl, job.fileName);
                            }
                          }}
                          className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors border border-slate-700 hover:border-slate-600"
                          title="Audit Quality for Adobe Stock"
                        >
                          <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
                          Analyze
                        </button>
                        <a
                          href={job.upscaledUrl}
                          download={`${job.fileName.replace(/\.[^/.]+$/, "")}_${job.scaleFactor}x.jpg`}
                          className="py-1.5 px-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center transition-colors shadow"
                          title="Download Upscaled JPEG"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => processJob(job.id)}
                          disabled={job.status === "processing"}
                          className="flex-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors"
                        >
                          <Play className="w-3.5 h-3.5 text-cyan-400" />
                          Upscale Now
                        </button>
                        <button
                          onClick={() => setJobs((prev) => prev.filter((j) => j.id !== job.id))}
                          className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                          title="Remove from queue"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-12 text-center">
          <div className="w-16 h-16 rounded-2xl bg-slate-800/60 border border-slate-700 text-slate-400 flex items-center justify-center mx-auto mb-4">
            <Layers className="w-8 h-8 text-slate-400" />
          </div>
          <h4 className="text-base font-semibold text-white">Batch Queue is Empty</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
            Drag and drop high-resolution or smartphone photos above, or click one of the stock presets to test 2x, 4x, and 8x super-resolution detail.
          </p>
          <div className="flex justify-center gap-3 mt-4">
            <button
              onClick={() => handleAddPreset(SAMPLE_PRESETS[0])}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-400 rounded-lg border border-slate-700 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Load Sample Studio Portrait
            </button>
          </div>
        </div>
      )}

      {/* Comparison Modal */}
      {activeCompareJob && activeCompareJob.upscaledUrl && (
        <ComparisonModal
          isOpen={Boolean(activeCompareJob)}
          onClose={() => setActiveCompareJob(null)}
          originalUrl={activeCompareJob.originalUrl}
          upscaledUrl={activeCompareJob.upscaledUrl}
          fileName={activeCompareJob.fileName}
          originalWidth={activeCompareJob.originalWidth}
          originalHeight={activeCompareJob.originalHeight}
          upscaledWidth={activeCompareJob.upscaledWidth}
          upscaledHeight={activeCompareJob.upscaledHeight}
          scaleFactor={activeCompareJob.scaleFactor}
          modelName={activeCompareJob.aiModel}
          qualityScore={activeCompareJob.qualityScore}
        />
      )}
    </div>
  );
}
