export interface QualityMetric {
  id: string;
  name: string;
  score: number; // 0 - 100
  status: "pass" | "warning" | "critical";
  valueText: string;
  warningMessage?: string;
  fixRecommendation?: string;
}

export interface AnalysisResult {
  overallScore: number;
  probabilityTier: "High" | "Medium" | "Low";
  verdict: string;
  megapixels: number;
  width: number;
  height: number;
  aspectRatio: string;
  metrics: {
    noise: QualityMetric;
    chromaticAberration: QualityMetric;
    sharpness: QualityMetric;
    compression: QualityMetric;
    exposureAndClipping: QualityMetric;
    resolution: QualityMetric;
  };
  rejectionRisks: string[];
  actionableFixes: string[];
  stockChecklist: {
    meetsMinResolution: boolean;
    recommendedCommercialMP: boolean;
    colorSpaceCheck: boolean;
    sharpnessVerified: boolean;
    noiseAcceptable: boolean;
  };
  histogram?: {
    r: number[];
    g: number[];
    b: number[];
    luminance: number[];
  };
  optimizedKeywords?: string[];
}

/**
 * Perform deep technical inspection of image bitmap data
 */
export async function analyzeImageFile(fileOrUrl: File | string): Promise<AnalysisResult> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";

    img.onload = () => {
      try {
        const width = img.naturalWidth || img.width;
        const height = img.naturalHeight || img.height;
        const megapixels = Number(((width * height) / 1000000).toFixed(2));

        // Offscreen sampling canvas
        const sampleWidth = Math.min(width, 1024);
        const sampleHeight = Math.round((height / width) * sampleWidth);

        const canvas = document.createElement("canvas");
        canvas.width = sampleWidth;
        canvas.height = sampleHeight;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });

        if (!ctx) {
          throw new Error("Could not create 2D canvas context");
        }

        ctx.drawImage(img, 0, 0, sampleWidth, sampleHeight);
        const imageData = ctx.getImageData(0, 0, sampleWidth, sampleHeight);
        const data = imageData.data;

        // 1. Sharpness & High Frequency Edge Variance (Laplacian operator)
        let laplacianSum = 0;
        let laplacianCount = 0;
        const gray = new Float32Array(sampleWidth * sampleHeight);

        for (let i = 0, p = 0; i < data.length; i += 4, p++) {
          gray[p] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        }

        // Measure edge variance
        for (let y = 1; y < sampleHeight - 1; y += 2) {
          for (let x = 1; x < sampleWidth - 1; x += 2) {
            const idx = y * sampleWidth + x;
            const lap =
              gray[idx - sampleWidth] +
              gray[idx + sampleWidth] +
              gray[idx - 1] +
              gray[idx + 1] -
              4 * gray[idx];
            laplacianSum += Math.abs(lap);
            laplacianCount++;
          }
        }

        const avgLaplacian = laplacianCount > 0 ? laplacianSum / laplacianCount : 15;
        // Map average laplacian to 0-100 sharpness score
        const rawSharpness = Math.min(100, Math.max(30, Math.round(avgLaplacian * 4.2)));
        const sharpnessScore = Math.min(98, Math.max(45, rawSharpness));

        // 2. Luminance & Shadow Noise Analysis (standard deviation in dark & flat regions)
        let darkPixelCount = 0;
        let darkDiffSum = 0;
        let blownHighlightCount = 0;
        let crushedBlackCount = 0;

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;

          if (lum < 40) {
            darkPixelCount++;
            // Check variance across RGB channels
            const diff = Math.abs(r - g) + Math.abs(g - b);
            darkDiffSum += diff;
          }

          if (lum > 251) blownHighlightCount++;
          if (lum < 3) crushedBlackCount++;
        }

        const shadowChromaVariance = darkPixelCount > 100 ? darkDiffSum / darkPixelCount : 4;
        const noiseScore = Math.max(
          35,
          Math.min(96, Math.round(100 - shadowChromaVariance * 2.8))
        );

        // 3. Chromatic Aberration (Radial color fringing at high contrast edges)
        let fringeEvidence = 0;
        let contrastEdgeCount = 0;

        for (let y = 2; y < sampleHeight - 2; y += 4) {
          for (let x = 2; x < sampleWidth - 2; x += 4) {
            const idx = (y * sampleWidth + x) * 4;
            const r1 = data[idx];
            const g1 = data[idx + 1];
            const b1 = data[idx + 2];

            const rightIdx = (y * sampleWidth + (x + 1)) * 4;
            const r2 = data[rightIdx];
            const g2 = data[rightIdx + 1];
            const b2 = data[rightIdx + 2];

            const lumDelta = Math.abs((r1 + g1 + b1) / 3 - (r2 + g2 + b2) / 3);
            if (lumDelta > 50) {
              contrastEdgeCount++;
              // Check purple or cyan shift (magenta = high R & B with low G; cyan = high G & B with low R)
              const redOffset = Math.abs(r1 - r2);
              const blueOffset = Math.abs(b1 - b2);
              const greenOffset = Math.abs(g1 - g2);
              if (Math.abs(redOffset - greenOffset) > 15 || Math.abs(blueOffset - greenOffset) > 15) {
                fringeEvidence++;
              }
            }
          }
        }

        const fringeRatio = contrastEdgeCount > 0 ? fringeEvidence / contrastEdgeCount : 0.05;
        const caScore = Math.max(40, Math.min(97, Math.round(100 - fringeRatio * 75)));

        // 4. Over-compression & Block Artifacts
        // Sample 8x8 block boundary deltas
        let blockBoundaryDelta = 0;
        let interiorDelta = 0;
        let blockTestCount = 0;

        for (let y = 8; y < sampleHeight - 8; y += 8) {
          for (let x = 8; x < sampleWidth - 8; x += 8) {
            const bIdx = (y * sampleWidth + x) * 4;
            const bNext = (y * sampleWidth + x + 1) * 4;
            const inIdx = (y * sampleWidth + x + 4) * 4;
            const inNext = (y * sampleWidth + x + 5) * 4;

            blockBoundaryDelta += Math.abs(data[bIdx] - data[bNext]);
            interiorDelta += Math.abs(data[inIdx] - data[inNext]);
            blockTestCount++;
          }
        }

        const blockRatio =
          blockTestCount > 0 && interiorDelta > 0
            ? blockBoundaryDelta / interiorDelta
            : 1.0;
        const compressionScore =
          blockRatio > 1.35
            ? Math.max(45, Math.round(95 - (blockRatio - 1.0) * 80))
            : Math.min(98, Math.max(82, Math.round(98 - (blockRatio - 1.0) * 20)));

        // 5. Exposure & Clipping
        const totalPixels = sampleWidth * sampleHeight;
        const blownPct = (blownHighlightCount / totalPixels) * 100;
        const crushedPct = (crushedBlackCount / totalPixels) * 100;
        let exposureScore = 95;
        if (blownPct > 3) exposureScore -= Math.round(blownPct * 5);
        if (crushedPct > 6) exposureScore -= Math.round(crushedPct * 3);
        exposureScore = Math.max(40, Math.min(98, exposureScore));

        // 6. Resolution Compliance
        let resScore = 95;
        if (megapixels < 4.0) {
          resScore = 30; // Direct rejection trigger on Adobe Stock
        } else if (megapixels < 12.0) {
          resScore = 75; // Acceptable but lower commercial tier
        } else if (megapixels >= 20.0) {
          resScore = 99; // Peak commercial stock standard
        }

        // Weighted Overall Score for Adobe Stock
        // Resolution is a hard blocker; noise & sharpness are top rejection reasons
        let overall = Math.round(
          sharpnessScore * 0.28 +
            noiseScore * 0.24 +
            caScore * 0.18 +
            compressionScore * 0.15 +
            exposureScore * 0.15
        );

        if (megapixels < 4.0) {
          overall = Math.min(50, overall); // Cannot exceed 50 if under 4MP
        }

        const probabilityTier: "High" | "Medium" | "Low" =
          overall >= 82 ? "High" : overall >= 68 ? "Medium" : "Low";

        let verdict = "";
        if (probabilityTier === "High") {
          verdict = "High Probability of Approval — Exceeds Adobe Stock technical standards";
        } else if (probabilityTier === "Medium") {
          verdict = "Conditional Approval — Minor technical flaws detected; quick Lightroom touchups recommended";
        } else {
          verdict = "High Risk of Technical Rejection — Likely to fail Adobe Stock Quality Review";
        }

        // Actionable feedback and rejection risks
        const rejectionRisks: string[] = [];
        const actionableFixes: string[] = [];

        if (megapixels < 4.0) {
          rejectionRisks.push(`Immediate Rejection Risk: Image is ${megapixels}MP. Adobe Stock enforces a strict 4.0 Megapixel minimum.`);
          actionableFixes.push("Use the ApertureAI 4x or 8x Upscaler to bring resolution above 16 Megapixels before submission.");
        } else if (megapixels < 12.0) {
          actionableFixes.push(`Upscale 2x or 4x to reach 24MP+ for high-paying billboard/print buyer licensing.`);
        }

        if (noiseScore < 75) {
          rejectionRisks.push("Warning: Luminance & chrominance noise detected in dark midtones/shadows.");
          actionableFixes.push("Apply Luminance Noise Reduction (+20 to +30) and Color Noise Reduction (+25) in Lightroom/Camera Raw.");
        }

        if (sharpnessScore < 72) {
          rejectionRisks.push("Warning: Image lacks critical micro-sharpness at 100% pixel inspection.");
          actionableFixes.push("Increase Sharpening amount with high Masking (60-80) to only crisp subject edges without amplifying sensor noise.");
        }

        if (caScore < 75) {
          rejectionRisks.push("Warning: Chromatic aberration (purple/cyan color fringing) detected along high-contrast silhouettes.");
          actionableFixes.push("Enable Lens Profile Corrections & Defringe (Purples amount: 4, Blues amount: 3) to strip edge fringing.");
        }

        if (compressionScore < 75) {
          rejectionRisks.push("Warning: JPEG blocking artifacts and quantization ringing detected.");
          actionableFixes.push("Export with JPEG Quality 10-12 (92-98%) and avoid repeated re-saving of compressed files.");
        }

        if (blownPct > 3) {
          rejectionRisks.push(`Highlight Clipping: ${blownPct.toFixed(1)}% of pixels are blown white (RGB 255/255/255).`);
          actionableFixes.push("Pull back Highlights (-30 to -60) or apply gentle radial burn filter to recover texture.");
        }

        if (rejectionRisks.length === 0) {
          rejectionRisks.push("No critical technical rejection triggers identified. Clean microstock profile.");
          actionableFixes.push("Asset is technically compliant. Ensure model release is attached if human subjects appear.");
        }

        const result: AnalysisResult = {
          overallScore: overall,
          probabilityTier,
          verdict,
          megapixels,
          width,
          height,
          aspectRatio: getAspectRatioString(width, height),
          metrics: {
            sharpness: {
              id: "sharpness",
              name: "Focus & Critical Sharpness",
              score: sharpnessScore,
              status: sharpnessScore >= 80 ? "pass" : sharpnessScore >= 65 ? "warning" : "critical",
              valueText: `${sharpnessScore}/100 Sharpness Index`,
              warningMessage:
                sharpnessScore < 70
                  ? "Soft focus or lens diffraction detected at 100% zoom"
                  : undefined,
              fixRecommendation:
                "Increase unsharp mask with edge masking threshold to protect skin and backgrounds.",
            },
            noise: {
              id: "noise",
              name: "Shadow & Luminance Noise",
              score: noiseScore,
              status: noiseScore >= 80 ? "pass" : noiseScore >= 65 ? "warning" : "critical",
              valueText: `${noiseScore}/100 SNR Cleanliness`,
              warningMessage:
                noiseScore < 70
                  ? "Elevated grain in shadow zones exceeds microstock inspection limits"
                  : undefined,
              fixRecommendation: "Apply targeted AI denoise or +25 luminance noise smoothing.",
            },
            chromaticAberration: {
              id: "chromaticAberration",
              name: "Chromatic Aberration & Fringing",
              score: caScore,
              status: caScore >= 82 ? "pass" : caScore >= 68 ? "warning" : "critical",
              valueText: `${caScore}/100 Edge Purity`,
              warningMessage:
                caScore < 75
                  ? "Color fringing visible at high-contrast backlit boundaries"
                  : undefined,
              fixRecommendation: "Turn on lens correction profile and manual purple defringe.",
            },
            compression: {
              id: "compression",
              name: "JPEG Compression & Artifacts",
              score: compressionScore,
              status: compressionScore >= 80 ? "pass" : compressionScore >= 65 ? "warning" : "critical",
              valueText: `${compressionScore}/100 Block Purity`,
              warningMessage:
                compressionScore < 75
                  ? "8x8 DCT quantization blocks and ringing detected"
                  : undefined,
              fixRecommendation: "Export as uncompressed TIFF or maximum quality JPEG.",
            },
            exposureAndClipping: {
              id: "exposureAndClipping",
              name: "Dynamic Range & Highlight Clipping",
              score: exposureScore,
              status: exposureScore >= 80 ? "pass" : exposureScore >= 65 ? "warning" : "critical",
              valueText: `${exposureScore}/100 Dynamic Range`,
              warningMessage:
                blownPct > 3 ? `${blownPct.toFixed(1)}% highlights blown to pure white` : undefined,
              fixRecommendation: "Recover highlights in RAW processor before JPEG rendering.",
            },
            resolution: {
              id: "resolution",
              name: "Adobe Stock Resolution Requirement",
              score: resScore,
              status: resScore >= 80 ? "pass" : resScore >= 60 ? "warning" : "critical",
              valueText: `${megapixels} Megapixels (${width} × ${height})`,
              warningMessage:
                megapixels < 4.0
                  ? "Below 4.0 MP minimum threshold — guaranteed rejection"
                  : megapixels < 12.0
                  ? "Meets minimum but below premium buyer resolution target (15-45MP)"
                  : undefined,
              fixRecommendation:
                megapixels < 4.0 ? "Batch upscale by 4x to clear minimum requirements." : undefined,
            },
          },
          rejectionRisks,
          actionableFixes,
          stockChecklist: {
            meetsMinResolution: megapixels >= 4.0,
            recommendedCommercialMP: megapixels >= 12.0,
            colorSpaceCheck: true,
            sharpnessVerified: sharpnessScore >= 70,
            noiseAcceptable: noiseScore >= 70,
          },
          optimizedKeywords: [
            "stock photography",
            "commercial license",
            "authentic",
            "high resolution",
            "professional",
            "editorial quality",
            "studio lighting",
            "copy space",
            "modern",
          ],
        };

        resolve(result);
      } catch (err) {
        reject(err);
      }
    };

    img.onerror = (e) => {
      reject(new Error("Failed to load image for analysis: " + e));
    };

    if (typeof fileOrUrl === "string") {
      img.src = fileOrUrl;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(fileOrUrl);
    }
  });
}

function getAspectRatioString(w: number, h: number): string {
  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const divisor = gcd(w, h);
  const rw = w / divisor;
  const rh = h / divisor;
  if (rw <= 16 && rh <= 16) {
    return `${rw}:${rh}`;
  }
  const ratio = (w / h).toFixed(2);
  if (ratio === "1.50") return "3:2 (Standard DSLR)";
  if (ratio === "1.33") return "4:3 (Medium Format / Micro 4/3)";
  if (ratio === "1.78") return "16:9 (Widescreen)";
  if (ratio === "1.00") return "1:1 (Square)";
  return `${ratio}:1`;
}
