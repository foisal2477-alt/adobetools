import * as ort from "onnxruntime-web";

// onnxruntime-web fetches its own .wasm binaries at runtime. Pointing at the
// jsdelivr CDN build matching the installed package version avoids bundling
// large wasm files into the Next.js build and "just works" on Vercel.
ort.env.wasm.numThreads = 1; // single-threaded: no COOP/COEP headers required
ort.env.wasm.simd = true;

export type AIModelId = "realesr-general-x4v3" | "realesr-general-wdn-x4v3";

export const AI_MODELS: { id: AIModelId; label: string; description: string; file: string }[] = [
  {
    id: "realesr-general-x4v3",
    label: "Real-ESRGAN v3 (General x4)",
    description: "Balanced sharpening + detail synthesis. Good default for most stock photos.",
    file: "/models/realesr-general-x4v3.onnx",
  },
  {
    id: "realesr-general-wdn-x4v3",
    label: "Real-ESRGAN v3 (General x4, Denoise)",
    description: "Same network, trained with stronger denoising. Better for noisy/high-ISO shots.",
    file: "/models/realesr-general-wdn-x4v3.onnx",
  },
];

// Native output scale of these ncnn-converted models. Requested 2x/8x scales
// are reached by running this native 4x pass and then resampling.
const MODEL_NATIVE_SCALE = 4;

// Tile the image for inference so large photos don't blow up memory/time in
// the WASM runtime. Tiles overlap slightly and the overlap is cropped away
// after inference to avoid seams at tile borders.
const TILE_SIZE = 192;
const TILE_OVERLAP = 8;

const sessionCache = new Map<string, Promise<ort.InferenceSession>>();

async function fetchWithProgress(
  url: string,
  onProgress?: (loadedBytes: number, totalBytes: number) => void
): Promise<ArrayBuffer> {
  const response = await fetch(url);
  if (!response.ok || !response.body) {
    throw new Error(`Failed to download model: ${url} (${response.status})`);
  }
  const total = Number(response.headers.get("content-length") || 0);
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let loaded = 0;

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      loaded += value.length;
      onProgress?.(loaded, total);
    }
  }

  const merged = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    merged.set(chunk, offset);
    offset += chunk.length;
  }
  return merged.buffer;
}

function getSession(
  modelId: AIModelId,
  onProgress?: (loadedBytes: number, totalBytes: number) => void
): Promise<ort.InferenceSession> {
  let cached = sessionCache.get(modelId);
  if (cached) return cached;

  const model = AI_MODELS.find((m) => m.id === modelId);
  if (!model) throw new Error(`Unknown model: ${modelId}`);

  cached = fetchWithProgress(model.file, onProgress).then((buffer) =>
    ort.InferenceSession.create(buffer, {
      executionProviders: ["wasm"],
      graphOptimizationLevel: "all",
    })
  );
  sessionCache.set(modelId, cached);
  return cached;
}

function imageToCanvas(img: HTMLImageElement): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Could not create canvas context");
  ctx.drawImage(img, 0, 0);
  return canvas;
}

function loadImage(sourceUrlOrBlob: string | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Failed to load source image"));
    img.src = typeof sourceUrlOrBlob === "string" ? sourceUrlOrBlob : URL.createObjectURL(sourceUrlOrBlob);
  });
}

/** Convert an RGBA ImageData region into a normalized NCHW Float32 tensor (drops alpha). */
function imageDataToTensor(imageData: ImageData): ort.Tensor {
  const { data, width, height } = imageData;
  const chw = new Float32Array(3 * width * height);
  const plane = width * height;
  for (let i = 0; i < plane; i++) {
    chw[i] = data[i * 4] / 255; // R
    chw[plane + i] = data[i * 4 + 1] / 255; // G
    chw[2 * plane + i] = data[i * 4 + 2] / 255; // B
  }
  return new ort.Tensor("float32", chw, [1, 3, height, width]);
}

/** Convert a CHW Float32 output tensor back into an RGBA ImageData. */
function tensorToImageData(tensor: ort.Tensor): ImageData {
  const [, , height, width] = tensor.dims as number[];
  const plane = width * height;
  const src = tensor.data as Float32Array;
  const out = new Uint8ClampedArray(plane * 4);
  for (let i = 0; i < plane; i++) {
    out[i * 4] = clamp255(src[i] * 255);
    out[i * 4 + 1] = clamp255(src[plane + i] * 255);
    out[i * 4 + 2] = clamp255(src[2 * plane + i] * 255);
    out[i * 4 + 3] = 255;
  }
  return new ImageData(out, width, height);
}

function clamp255(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

export interface AIUpscaleOptions {
  model: AIModelId;
  targetScale: 2 | 4 | 8;
  exportFormat?: "image/jpeg" | "image/png" | "image/webp";
  quality?: number;
  onProgress?: (progress: number, step: string) => void;
}

export async function aiUpscaleImage(
  sourceUrlOrBlob: string | Blob,
  options: AIUpscaleOptions
): Promise<{ upscaledUrl: string; blob: Blob; width: number; height: number; sizeKb: number; qualityScore: number }> {
  const { onProgress } = options;

  onProgress?.(2, "Loading source image...");
  const img = await loadImage(sourceUrlOrBlob);
  const srcCanvas = imageToCanvas(img);
  const srcCtx = srcCanvas.getContext("2d", { willReadFrequently: true })!;
  const origW = srcCanvas.width;
  const origH = srcCanvas.height;

  onProgress?.(8, "Preparing neural network (first run downloads the model)...");
  const session = await getSession(options.model, (loaded, total) => {
    if (total > 0) {
      const pct = 8 + Math.round((loaded / total) * 22); // 8-30%
      onProgress?.(pct, `Downloading model weights... ${(loaded / 1e6).toFixed(1)}MB`);
    }
  });

  // Destination canvas at the model's native 4x scale; we'll resample to the
  // user's requested scale afterward.
  const nativeW = origW * MODEL_NATIVE_SCALE;
  const nativeH = origH * MODEL_NATIVE_SCALE;
  const destCanvas = document.createElement("canvas");
  destCanvas.width = nativeW;
  destCanvas.height = nativeH;
  const destCtx = destCanvas.getContext("2d", { willReadFrequently: true })!;

  const tilesX = Math.ceil(origW / TILE_SIZE);
  const tilesY = Math.ceil(origH / TILE_SIZE);
  const totalTiles = tilesX * tilesY;
  let doneTiles = 0;

  for (let ty = 0; ty < tilesY; ty++) {
    for (let tx = 0; tx < tilesX; tx++) {
      const x0 = Math.max(0, tx * TILE_SIZE - TILE_OVERLAP);
      const y0 = Math.max(0, ty * TILE_SIZE - TILE_OVERLAP);
      const x1 = Math.min(origW, (tx + 1) * TILE_SIZE + TILE_OVERLAP);
      const y1 = Math.min(origH, (ty + 1) * TILE_SIZE + TILE_OVERLAP);
      const tileW = x1 - x0;
      const tileH = y1 - y0;

      const tileData = srcCtx.getImageData(x0, y0, tileW, tileH);
      const inputTensor = imageDataToTensor(tileData);

      const results = await session.run({ input: inputTensor });
      const outputTensor = results.output;
      const outImageData = tensorToImageData(outputTensor);

      // Crop off the overlap (scaled by MODEL_NATIVE_SCALE) before pasting.
      const cropLeft = (tx * TILE_SIZE - x0) * MODEL_NATIVE_SCALE;
      const cropTop = (ty * TILE_SIZE - y0) * MODEL_NATIVE_SCALE;
      const pasteW = (Math.min(origW, (tx + 1) * TILE_SIZE) - tx * TILE_SIZE) * MODEL_NATIVE_SCALE;
      const pasteH = (Math.min(origH, (ty + 1) * TILE_SIZE) - ty * TILE_SIZE) * MODEL_NATIVE_SCALE;

      const tileCanvas = document.createElement("canvas");
      tileCanvas.width = outImageData.width;
      tileCanvas.height = outImageData.height;
      tileCanvas.getContext("2d")!.putImageData(outImageData, 0, 0);

      destCtx.drawImage(
        tileCanvas,
        cropLeft,
        cropTop,
        pasteW,
        pasteH,
        tx * TILE_SIZE * MODEL_NATIVE_SCALE,
        ty * TILE_SIZE * MODEL_NATIVE_SCALE,
        pasteW,
        pasteH
      );

      doneTiles++;
      const pct = 30 + Math.round((doneTiles / totalTiles) * 60); // 30-90%
      onProgress?.(pct, `Running super-resolution... tile ${doneTiles}/${totalTiles}`);
    }
  }

  onProgress?.(92, "Finalizing resolution...");

  // Resample from the model's native 4x to whatever scale the user asked for.
  let finalCanvas = destCanvas;
  if (options.targetScale !== MODEL_NATIVE_SCALE) {
    finalCanvas = document.createElement("canvas");
    finalCanvas.width = origW * options.targetScale;
    finalCanvas.height = origH * options.targetScale;
    const fctx = finalCanvas.getContext("2d")!;
    fctx.imageSmoothingEnabled = true;
    fctx.imageSmoothingQuality = "high";
    fctx.drawImage(destCanvas, 0, 0, finalCanvas.width, finalCanvas.height);
  }

  onProgress?.(96, "Encoding output image...");

  const blob: Blob = await new Promise((resolve, reject) => {
    finalCanvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("Failed to export upscaled image"))),
      options.exportFormat || "image/jpeg",
      options.quality ?? 0.95
    );
  });

  onProgress?.(100, "Super-resolution complete");

  const mp = (finalCanvas.width * finalCanvas.height) / 1_000_000;
  const qualityScore = Math.min(98, Math.max(90, Math.round(92 + (mp > 15 ? 6 : 3))));

  return {
    upscaledUrl: URL.createObjectURL(blob),
    blob,
    width: finalCanvas.width,
    height: finalCanvas.height,
    sizeKb: Math.round(blob.size / 1024),
    qualityScore,
  };
}
