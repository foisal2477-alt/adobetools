import { NextResponse } from "next/server";
import { db } from "@/db";
import { shotPlans } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeedData();
    const shoots = await db.select().from(shotPlans).orderBy(desc(shotPlans.createdAt));
    return NextResponse.json({ shoots });
  } catch (error) {
    console.error("GET /api/shoots error:", error);
    return NextResponse.json({ error: "Failed to fetch shoots" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      title,
      themeCategory,
      targetAgency,
      shootDate,
      submissionDeadline,
      status,
      estimatedEarnings,
      targetImageCount,
      location,
      gearNotes,
      keywords,
      shotList,
      notes,
    } = body;

    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }

    const [newShoot] = await db
      .insert(shotPlans)
      .values({
        title,
        themeCategory: themeCategory || "Lifestyle",
        targetAgency: targetAgency || "Adobe Stock",
        shootDate: shootDate || null,
        submissionDeadline: submissionDeadline || null,
        status: status || "planned",
        estimatedEarnings: Number(estimatedEarnings || 0),
        targetImageCount: Number(targetImageCount || 15),
        location: location || "",
        gearNotes: gearNotes || "",
        keywords: keywords || "",
        shotList: shotList || [],
        notes: notes || "",
      })
      .returning();

    return NextResponse.json({ shoot: newShoot }, { status: 201 });
  } catch (error) {
    console.error("POST /api/shoots error:", error);
    return NextResponse.json({ error: "Failed to create shoot" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: "Shoot ID is required" }, { status: 400 });
    }

    const [updated] = await db
      .update(shotPlans)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(shotPlans.id, Number(id)))
      .returning();

    return NextResponse.json({ shoot: updated });
  } catch (error) {
    console.error("PUT /api/shoots error:", error);
    return NextResponse.json({ error: "Failed to update shoot" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await db.delete(shotPlans).where(eq(shotPlans.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/shoots error:", error);
    return NextResponse.json({ error: "Failed to delete shoot" }, { status: 500 });
  }
}
