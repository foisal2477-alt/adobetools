import { NextResponse } from "next/server";
import { db } from "@/db";
import { upscaleHistory } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const records = await db.select().from(upscaleHistory).orderBy(desc(upscaleHistory.createdAt)).limit(20);
    return NextResponse.json({ history: records });
  } catch (error) {
    console.error("GET /api/history error:", error);
    return NextResponse.json({ error: "Failed to fetch history" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      fileName,
      originalWidth,
      originalHeight,
      upscaledWidth,
      upscaledHeight,
      scaleFactor,
      aiModel,
      qualityScore,
      fileSizeKb,
      status,
      detectedIssues,
    } = body;

    const [record] = await db
      .insert(upscaleHistory)
      .values({
        fileName: fileName || "stock_photo.jpg",
        originalWidth: Number(originalWidth || 0),
        originalHeight: Number(originalHeight || 0),
        upscaledWidth: Number(upscaledWidth || 0),
        upscaledHeight: Number(upscaledHeight || 0),
        scaleFactor: Number(scaleFactor || 4),
        aiModel: aiModel || "Real-ESRGAN v3 Photo",
        qualityScore: Number(qualityScore || 85),
        fileSizeKb: Number(fileSizeKb || 0),
        status: status || "completed",
        detectedIssues: detectedIssues || [],
      })
      .returning();

    return NextResponse.json({ record }, { status: 201 });
  } catch (error) {
    console.error("POST /api/history error:", error);
    return NextResponse.json({ error: "Failed to save history" }, { status: 500 });
  }
}
