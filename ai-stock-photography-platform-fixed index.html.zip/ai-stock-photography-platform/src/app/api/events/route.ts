import { NextResponse } from "next/server";
import { db } from "@/db";
import { globalEvents } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { eq, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureSeedData();
    const { searchParams } = new URL(request.url);
    const month = searchParams.get("month");
    const category = searchParams.get("category");
    const country = searchParams.get("country");

    const events = await db.select().from(globalEvents);

    let filtered = events;

    if (month && month !== "all") {
      filtered = filtered.filter((e) => e.month === Number(month));
    }

    if (category && category !== "all") {
      filtered = filtered.filter((e) => e.category.toLowerCase() === category.toLowerCase());
    }

    if (country && country !== "all") {
      filtered = filtered.filter(
        (e) => e.countryCode === "GLOBAL" || e.countryCode.toLowerCase() === country.toLowerCase()
      );
    }

    // Sort by date
    filtered.sort((a, b) => a.date.localeCompare(b.date));

    return NextResponse.json({ events: filtered });
  } catch (error) {
    console.error("GET /api/events error:", error);
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, date, month, countryCode, category, description, leadTimeWeeks, suggestedKeywords, contentIdeas } = body;

    if (!name || !date || !month) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const [newEvent] = await db
      .insert(globalEvents)
      .values({
        name,
        date,
        month: Number(month),
        countryCode: countryCode || "GLOBAL",
        category: category || "holiday",
        description: description || "",
        leadTimeWeeks: Number(leadTimeWeeks || 6),
        suggestedKeywords: suggestedKeywords || "",
        contentIdeas: contentIdeas || [],
        isPopularStockTheme: true,
      })
      .returning();

    return NextResponse.json({ event: newEvent }, { status: 201 });
  } catch (error) {
    console.error("POST /api/events error:", error);
    return NextResponse.json({ error: "Failed to create event" }, { status: 500 });
  }
}
