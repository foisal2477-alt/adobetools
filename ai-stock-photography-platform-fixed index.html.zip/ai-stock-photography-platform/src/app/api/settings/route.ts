import { NextResponse } from "next/server";
import { db } from "@/db";
import { contributorSettings } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeedData();
    const settings = await db.select().from(contributorSettings).limit(1);
    if (settings.length > 0) {
      // Mask API keys for safe client display
      const item = settings[0];
      return NextResponse.json({
        settings: {
          ...item,
          hasReplicateKey: Boolean(item.replicateApiKey && item.replicateApiKey.length > 5),
          hasStabilityKey: Boolean(item.stabilityApiKey && item.stabilityApiKey.length > 5),
          replicateApiKeyMasked: item.replicateApiKey
            ? `${item.replicateApiKey.slice(0, 4)}...${item.replicateApiKey.slice(-4)}`
            : "",
          stabilityApiKeyMasked: item.stabilityApiKey
            ? `${item.stabilityApiKey.slice(0, 4)}...${item.stabilityApiKey.slice(-4)}`
            : "",
        },
      });
    }
    return NextResponse.json({ settings: null });
  } catch (error) {
    console.error("GET /api/settings error:", error);
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeedData();
    const body = await request.json();
    const {
      contributorName,
      replicateApiKey,
      stabilityApiKey,
      defaultScaleFactor,
      defaultModel,
      autoDenoise,
      autoSharpen,
      targetColorSpace,
      minMegapixels,
      exportFormat,
    } = body;

    const existing = await db.select().from(contributorSettings).limit(1);

    if (existing.length > 0) {
      const updateData: Record<string, unknown> = {
        updatedAt: new Date(),
      };
      if (contributorName !== undefined) updateData.contributorName = contributorName;
      if (replicateApiKey !== undefined && replicateApiKey !== "") updateData.replicateApiKey = replicateApiKey;
      if (stabilityApiKey !== undefined && stabilityApiKey !== "") updateData.stabilityApiKey = stabilityApiKey;
      if (defaultScaleFactor !== undefined) updateData.defaultScaleFactor = Number(defaultScaleFactor);
      if (defaultModel !== undefined) updateData.defaultModel = defaultModel;
      if (autoDenoise !== undefined) updateData.autoDenoise = Boolean(autoDenoise);
      if (autoSharpen !== undefined) updateData.autoSharpen = Boolean(autoSharpen);
      if (targetColorSpace !== undefined) updateData.targetColorSpace = targetColorSpace;
      if (minMegapixels !== undefined) updateData.minMegapixels = Number(minMegapixels);
      if (exportFormat !== undefined) updateData.exportFormat = exportFormat;

      const [updated] = await db
        .update(contributorSettings)
        .set(updateData)
        .where(eq(contributorSettings.id, existing[0].id))
        .returning();

      return NextResponse.json({ success: true, settings: updated });
    } else {
      const [created] = await db
        .insert(contributorSettings)
        .values({
          contributorName: contributorName || "Adobe Stock Contributor",
          replicateApiKey: replicateApiKey || "",
          stabilityApiKey: stabilityApiKey || "",
          defaultScaleFactor: Number(defaultScaleFactor || 4),
          defaultModel: defaultModel || "Real-ESRGAN v3 Photo",
          autoDenoise: autoDenoise ?? true,
          autoSharpen: autoSharpen ?? true,
          targetColorSpace: targetColorSpace || "sRGB",
          minMegapixels: Number(minMegapixels || 12),
          exportFormat: exportFormat || "JPEG (High 95%)",
        })
        .returning();

      return NextResponse.json({ success: true, settings: created });
    }
  } catch (error) {
    console.error("POST /api/settings error:", error);
    return NextResponse.json({ error: "Failed to save settings" }, { status: 500 });
  }
}
