import type { Metadata } from "next";
import { ReactNode } from "react";
import "./globals.css";
import { ToastProvider } from "@/components/Toast";

export const metadata: Metadata = {
  title: "ApertureAI — Stock Contributor Studio | AI Batch Upscaler & Quality Analyzer",
  description:
    "Production-grade stock photography platform featuring 2x/4x/8x AI Batch Upscaling, Adobe Stock Rejection Prevention Quality Analyzer, and Global Seasonal Event Calendar.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-cyan-500 selection:text-slate-950 min-h-screen">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
