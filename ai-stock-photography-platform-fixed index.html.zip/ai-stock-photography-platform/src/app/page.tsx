"use client";

import React, { useState } from "react";
import { Navbar, ActiveTab } from "@/components/Navbar";
import { BatchUpscaler } from "@/components/BatchUpscaler";
import { QualityAnalyzer } from "@/components/QualityAnalyzer";
import { EventCalendar, StockEvent } from "@/components/EventCalendar";
import { ShotPlanner } from "@/components/ShotPlanner";
import { SettingsModal } from "@/components/SettingsModal";
import {
  Sparkles,
  ShieldCheck,
  Calendar,
  Camera,
  CheckCircle2,
  ExternalLink,
  Layers,
  ArrowUpRight,
  Sliders,
  HelpCircle,
  FileText,
} from "lucide-react";

export default function ContributorStudioPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("upscaler");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Cross-module states
  const [analyzerImageUrl, setAnalyzerImageUrl] = useState<string | null>(null);
  const [analyzerFileName, setAnalyzerFileName] = useState<string | null>(null);

  const handleSendToAnalyzer = (url: string, name: string) => {
    setAnalyzerImageUrl(url);
    setAnalyzerFileName(name);
    setActiveTab("analyzer");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSendToUpscaler = (url: string) => {
    setActiveTab("upscaler");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddToShotPlanner = async (event: StockEvent) => {
    const shootDeadline = new Date(
      new Date(event.date).getTime() - event.leadTimeWeeks * 7 * 24 * 60 * 60 * 1000
    ).toISOString().split("T")[0];

    try {
      await fetch("/api/shoots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${event.name} Commercial Stock Shoot`,
          themeCategory: event.category.toUpperCase(),
          targetAgency: "Adobe Stock",
          shootDate: null,
          submissionDeadline: shootDeadline,
          status: "planned",
          estimatedEarnings: 900,
          targetImageCount: 20,
          location: "Studio / On-Location Set",
          gearNotes: "Full-frame camera, 50mm f/1.4, clean background reflector",
          keywords: event.suggestedKeywords,
          shotList: event.contentIdeas || ["Authentic hero portrait", "Flatlay with copy space"],
          notes: `Created from Global Event Calendar. Optimal submission deadline: ${shootDeadline}`,
        }),
      });
      setActiveTab("planner");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "upscaler" && (
          <div className="animate-in fade-in duration-300">
            <BatchUpscaler onSendToAnalyzer={handleSendToAnalyzer} />
          </div>
        )}

        {activeTab === "analyzer" && (
          <div className="animate-in fade-in duration-300">
            <QualityAnalyzer
              initialImageUrl={analyzerImageUrl}
              initialFileName={analyzerFileName}
              onSendToUpscaler={handleSendToUpscaler}
            />
          </div>
        )}

        {activeTab === "calendar" && (
          <div className="animate-in fade-in duration-300">
            <EventCalendar onAddToShotPlanner={handleAddToShotPlanner} />
          </div>
        )}

        {activeTab === "planner" && (
          <div className="animate-in fade-in duration-300">
            <ShotPlanner />
          </div>
        )}
      </main>

      {/* Enterprise Contributor Standards Footer */}
      <footer className="mt-16 border-t border-slate-900 bg-slate-950/90 text-slate-400 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center">
                <Camera className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-bold text-white text-sm">
                Aperture<span className="text-cyan-400">AI</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Engineered specifically for microstock contributors submitting to Adobe Stock, Shutterstock, and Getty Images.
            </p>
            <div className="text-[11px] text-slate-400">
              © 2026 ApertureAI Contributor Studio. All rights reserved.
            </div>
          </div>

          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              Stock Rejection Standards
            </h5>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-1.5 text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Minimum 4.0 Megapixels required</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Zero visible logos, trademarks, or IP</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Clean 100% zoom shadow noise limits</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Signed model release for all faces</span>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              Super-Resolution Models
            </h5>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>• Real-ESRGAN v3 Photo (Commercial)</li>
              <li>• Topaz Detail Boost Pro (Micro-texture)</li>
              <li>• Adobe Stock Super-Res Pro (300 DPI)</li>
              <li>• Clarity De-block & Denoise Engine</li>
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              Seasonal Lead Times
            </h5>
            <p className="text-xs text-slate-400 leading-relaxed">
              Adobe Stock content indexing takes 6 to 10 weeks. Use our calendar to schedule shoots in advance of seasonal buyer search volume spikes.
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[10px] text-cyan-300">
                Current window: Summer & Autumn 2026
              </span>
            </div>
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}
